package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.service.CustomerService;

@Controller
public class CustomerController {
	
	@Autowired
	CustomerService customerservice;
	
	@GetMapping("/")
	public String loginpage() {
		System.out.println("login page called::");
		return "login";
	}
	
	@GetMapping("/login")
	public String CustomerCredentials(@RequestParam("username") String username, @RequestParam("password") String password, Model model) {
		System.out.println("UserName:"+username+" password:"+password);
		
		
		boolean flag =customerservice.verifyCustomerCredentials(username,password);
		if(flag) {
			return "success";
			
		}else {
			model.addAttribute("msg", "Username and Password are incorrect.please try again later.");
			return "login";
			
		}

	}
	
	

}
