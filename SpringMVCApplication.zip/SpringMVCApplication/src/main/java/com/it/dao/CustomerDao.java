package com.it.dao;

import com.it.model.Customer;

public interface CustomerDao {

	Customer getCustomerByEmailid(String username);

}
