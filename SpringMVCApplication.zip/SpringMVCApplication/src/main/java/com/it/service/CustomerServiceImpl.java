package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.CustomerDao;
import com.it.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerDao cd;

	public boolean verifyCustomerCredentials(String username, String password) {
		
		Customer customer=cd.getCustomerByEmailid(username);
		
		if(customer.getCustomeremail().equals(username) && customer.getCustomerpassword().equals(password)) {
			
			return true ;
		}else {
			return false;
		}
		
		
		
	}

}
