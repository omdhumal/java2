package service;

import java.util.List;

import dao.CustomerDao;
import model.Customer;

public class CustomerService {

	public boolean checkData(String userEmail, String password) {
	
		
		System.out.println("Service layer Called..!");
		
		CustomerDao cd = new CustomerDao();
		   Customer customer= cd.fetchDbData(userEmail);
		
		if( customer !=null && userEmail != null && userEmail.equalsIgnoreCase(customer.getCustomeremail()) && password.equals(customer.getCustomerpassword())) {
			return true;
			
		}else {
		   
		   return false;
		}
	}
	public String saveDatainDb(Customer customer) {
		
		CustomerDao cd = new CustomerDao();
		String msg=cd.savedata(customer);
		return msg;
		
	}
	
	
	public List<Customer> fetchdta(){
		CustomerDao cd = new CustomerDao();
        return cd.fetchAllCustomersData();
	}
	public boolean deleteDatabyid(int customerid) {
		CustomerDao cdd = new  CustomerDao();
		boolean flag=cdd.deleteCustomerData(customerid);
		return flag;

		
	}
	public Customer UpdateDataByid(int customerid) {
		CustomerDao cdd = new  CustomerDao();
         Customer customeru =cdd.updateDataofCust(customerid);
		return customeru;
		
	}
	public boolean updateddata(Customer customer2) {
		CustomerDao cdu = new  CustomerDao();

		boolean flag=cdu.CustomerUpdatedData(customer2);
		return flag;
		
	}

}
