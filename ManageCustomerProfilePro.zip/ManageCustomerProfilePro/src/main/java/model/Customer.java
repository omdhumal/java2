package model;

public class Customer {
	private int  customerid;
	private String customername;
	private String customeremail;
	private String customerpassword;
	private String customergender;
	private String customercountry;
	private long contactno;
	
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getCustomeremail() {
		return customeremail;
	}
	public void setCustomeremail(String customeremail) {
		this.customeremail = customeremail;
	}
	public String getCustomerpassword() {
		return customerpassword;
	}
	public void setCustomerpassword(String customerpassword) {
		this.customerpassword = customerpassword;
	}
	public String getCustomergender() {
		return customergender;
	}
	public void setCustomergender(String customergender) {
		this.customergender = customergender;
	}
	public String getCustomercountry() {
		return customercountry;
	}
	public void setCustomercountry(String customercountry) {
		this.customercountry = customercountry;
	}
	public long getContactno() {
		return contactno;
	}
	public void setContactno(long contactno) {
		this.contactno = contactno;
	}
	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customername=" + customername + ", customeremail="
				+ customeremail + ", customerpassword=" + customerpassword + ", customergender=" + customergender
				+ ", customercountry=" + customercountry + ", contactno=" + contactno + "]";
	}
	
	
	
	

}
