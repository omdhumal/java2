package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.Customer;

public class CustomerDao {
	
	public Customer fetchDbData(String userEmail) {
		Customer customer = new Customer();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","Dhumal@123");
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select email,password from b19.custdata where email='"+userEmail+"'");
			
			while(rs.next()) {
           String email= rs.getString("email");
           String password = rs.getString("password");
			customer.setCustomeremail(email);
			customer.setCustomerpassword(password);
			
			
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customer;
		
	}

	public String savedata(Customer customer) {
		String msg="";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","Dhumal@123");
            PreparedStatement pstmt = conn.prepareStatement("insert into custdata(name,email,password,gender,country,contactno) values(?,?,?,?,?,?)");
			pstmt.setString(1, customer.getCustomername());
			pstmt.setString(2, customer.getCustomeremail());
			pstmt.setString(3, customer.getCustomerpassword());
			pstmt.setString(4, customer.getCustomergender());
			pstmt.setString(5, customer.getCustomercountry());
			pstmt.setLong(6, customer.getContactno());
			
			int i=pstmt.executeUpdate();
			if(i>0) {
				msg="success";
			}
		}catch(SQLException se) {
			msg="duplicate";
			
			
		} catch (Exception e) {
			
			msg="NetworkIssue";
			
			e.printStackTrace();
		}
		return msg;
		
	}
	
	public List<Customer> fetchAllCustomersData() {
		
		List<Customer > listofcustomer = new ArrayList<Customer>();
		
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","Dhumal@123");
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select * from b19.custdata ");
		
		while(rs.next()) {
			Customer customer = new Customer();

		customer.setCustomeremail(rs.getString("email"));
		customer.setCustomerpassword(rs.getString("password"));
		customer.setCustomerid(rs.getInt("id"));
		customer.setCustomername(rs.getString("name"));
		customer.setCustomergender(rs.getString("gender"));
		customer.setCustomercountry(rs.getNString("country"));
		customer.setContactno(rs.getLong("contactno"));

		listofcustomer.add(customer);
		
		}
		
	} catch (Exception e) {
		e.printStackTrace();
	}
	return listofcustomer;
	
}

	public boolean deleteCustomerData(int customerid) {
		boolean b = false;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","Dhumal@123");
		Statement stmt = conn.createStatement();
		int id = stmt.executeUpdate("delete from b19.custdata where id ='"+customerid+"'");
		System.out.println("id"+id);
		
		if(id>0) {
			b= true;
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		return b;
		
	}

	public Customer updateDataofCust(int customerid) {
		Customer customer = new Customer();

		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","Dhumal@123");
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select * from b19.custdata where id='"+customerid+"'");
		
      while(rs.next()) {
		customer.setCustomeremail(rs.getString("email"));
		customer.setCustomerpassword(rs.getString("password"));
		customer.setCustomerid(rs.getInt("id"));
		customer.setCustomername(rs.getString("name"));
		customer.setCustomergender(rs.getString("gender"));
		customer.setCustomercountry(rs.getNString("country"));
		customer.setContactno(rs.getLong("contactno"));

}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return customer;
		
	}

	public boolean CustomerUpdatedData(Customer customer2) {
		System.out.println("in dao");

		boolean flag = false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/b19","root","Dhumal@123");
            PreparedStatement pstmt = conn.prepareStatement("update custdata set name=?, password=?,gender=?, country=?, contactno=? where email=?");
			
            //pstmt.setInt(7, customer2.getCustomerid());
            pstmt.setString(1, customer2.getCustomername());
			pstmt.setString(6, customer2.getCustomeremail());
			pstmt.setString(2, customer2.getCustomerpassword());
			pstmt.setString(3, customer2.getCustomergender());
			pstmt.setString(4, customer2.getCustomercountry());
			pstmt.setLong(5, customer2.getContactno());
			
			int i =pstmt.executeUpdate();
			System.out.println("i="+i);
			if(i>0) {
				flag= true;
			}
			}catch(Exception e) {
				e.printStackTrace();
				System.out.println("error occure in update dao");
			}
		return flag;
	}
		
		
		
		
	}
	
	


