package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Customer;
import service.CustomerService;

/**
 * Servlet implementation class SaveController
 */
@WebServlet("/SaveController")
public class SaveController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Customer customer = new Customer ();
		
		customer.setCustomername(request.getParameter("custName"));
		customer.setCustomeremail(request.getParameter("custEmail"));
		customer.setCustomerpassword(request.getParameter("password"));
		customer.setContactno(Long.valueOf(request.getParameter("custContact")));
		customer.setCustomergender(request.getParameter("gender"));
		customer.setCustomercountry((request.getParameter("country")));
		
		
		CustomerService cs = new CustomerService();
		String msg=cs.saveDatainDb(customer);
		
		if(request.getParameter("custName") != null && request.getParameter("custName").isEmpty()) {
			request.setAttribute("EmptyMsg", "please fill all fields");
			RequestDispatcher rs = request.getRequestDispatcher("signup.jsp");
			rs.forward(request, response);	
			
		}
		
		else if(msg.equals("success") ) {
			request.setAttribute("Message", "Your profile has been created Sucessfully..! Please login");
			RequestDispatcher rs = request.getRequestDispatcher("index.jsp");
			rs.forward(request, response);
			}
		else if(msg.equals("duplicate")) {
			request.setAttribute("customer", customer);
			request.setAttribute("Message", "Your Email is duplicate. Please Try another.");
			RequestDispatcher rs = request.getRequestDispatcher("signup.jsp");
			rs.forward(request, response);
			}
		
		else {
				request.setAttribute("Message", "Due to some network issue your profile has not been created.Try after some time");
				RequestDispatcher rs = request.getRequestDispatcher("signup.jsp");
				rs.forward(request, response);
				}
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
