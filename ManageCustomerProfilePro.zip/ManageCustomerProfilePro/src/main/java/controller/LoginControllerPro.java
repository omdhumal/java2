package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.CustomerService;

/**
 * Servlet implementation class LoginControllerPro
 */
@WebServlet("/LoginControllerPro")
public class LoginControllerPro extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginControllerPro() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("LoginControllerPro called...!!");
		String email =request.getParameter("email");
		String password = request.getParameter("password");
		
		//String email="om@gmail.com";
		//String password="dd";
		
		
		
		System.out.println("email: "+email);
		System.out.println("password: "+password);
		
		CustomerService cs = new CustomerService();
		  boolean flag=cs.checkData(email,password);
		  
		  if(flag) {
			  List list = cs.fetchdta();
			  request.setAttribute("list", list);
			  RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
			  rd.forward(request, response);
		  }else {
			  request.setAttribute("msg", "userid and password are incorrect..!");
			  RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			  rd.forward(request, response);
		  }
		
		
		
		
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
