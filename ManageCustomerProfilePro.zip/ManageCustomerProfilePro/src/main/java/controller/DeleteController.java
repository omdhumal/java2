package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.result.IntegerValueFactory;

import model.Customer;
import service.CustomerService;

/**
 * Servlet implementation class DeleteController
 */
@WebServlet("/delete")
public class DeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	int customerid=	Integer.valueOf(request.getParameter("id"));
	
	
	System.out.println("customerId: "+customerid);
	CustomerService cs = new CustomerService();
	List list = cs.fetchdta();
	  request.setAttribute("list", list);
	  RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
	  	rd.forward(request, response);

	CustomerService csd = new CustomerService();
	
	   boolean flag=csd.deleteDatabyid(customerid);
	
	    if(flag) {
	    	
	    	request.setAttribute("msg", "Data deleted successfully..!"); 
	    	
	    	RequestDispatcher rd1 = request.getRequestDispatcher("success.jsp");
			rd1.forward(request, response);

	    	
	    	
	    	
	    }else {
	    	request.setAttribute("message", "Customer could not be deleted due to some network issue. Please try after some time.");
			RequestDispatcher rd2 = request.getRequestDispatcher("success.jsp");
			rd2.forward(request, response);

	    }
	
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
