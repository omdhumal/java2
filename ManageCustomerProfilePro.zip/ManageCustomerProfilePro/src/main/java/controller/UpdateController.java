package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Customer;
import service.CustomerService;

/**
 * Servlet implementation class UpdateController
 */
@WebServlet("/update")
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
		
		
		int customerid=	Integer.valueOf(request.getParameter("id"));
		
		
		System.out.println("updateid="+customerid);
		
		CustomerService cs = new CustomerService();
		Customer customerupdate = cs.UpdateDataByid(customerid);
		
		
		if(request.getParameter("custName") == null) {
		
		
		if(customerupdate != null) {
			RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
			request.setAttribute("customer", customerupdate);
			rd.forward(request, response);

		}else {
			request.setAttribute("message", "can,t update due to network issue.");
			RequestDispatcher rd = request.getRequestDispatcher("success.jsp");

		}
		
		}else {
			
			
			//Customer customer2 = cs.UpdateDataByid(customerid);
            Customer customer2 = new Customer();
		//	customer2.setCustomerid(customerid);
			customer2.setCustomername(request.getParameter("custName"));
			customer2.setCustomeremail(request.getParameter("custEmail"));
			customer2.setCustomerpassword(request.getParameter("password"));
			customer2.setContactno(Long.valueOf(request.getParameter("custContact")));
			customer2.setCustomergender(request.getParameter("gender"));
			customer2.setCustomercountry((request.getParameter("country")));
			cs.UpdateDataByid(customerid);
			CustomerService csu = new CustomerService();

			boolean flag = csu.updateddata(customer2);
			
			if(flag) {
				CustomerService css = new CustomerService();
				List<Customer > listofcustomer = css.fetchdta();
				request.setAttribute("list", listofcustomer);

				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				request.setAttribute("message", "Customer has been updated successfully..!");
				request.setAttribute("msgg", "Customer has been updated successfully..!");

				rd.forward(request, response);			
			
		}else {
			
			request.setAttribute("message", "Customer has been not updated due to some network issue.");
			request.setAttribute("customer", customerupdate);

			RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
			rd.forward(request, response);


		}
			
		
		
		}
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
