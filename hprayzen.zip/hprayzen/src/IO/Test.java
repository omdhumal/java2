package IO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;


public class Test {
	/*	public void writeIntFile() {
			
			String str = "Welcome in the world of Photon !!";
			
		}*/
		
		public static void main(String[] args) {
			
			Test t = new Test();
			String str = "Welcome in the world of Photon!!";

			/*try {
			File file = new File("C:\\Users\\old19\\OneDrive\\Desktop\\IOTest.txt");
			
			
			
			FileOutputStream fis = new FileOutputStream(file);
		
			fis.write(str.getBytes());
			fis.close();
			}catch(Exception e) {
				
				e.printStackTrace();	
			}*/
			
		try {
			File fi = new File("C:\\Users\\old19\\OneDrive\\Desktop\\IOTest.txt");
			FileInputStream f = new FileInputStream(fi);
			
			int i = 0;
			
			while((i=f.read()) != -1) {
				
				System.out.print((char)i);
			}
			}catch(Exception e) {
				
				e.printStackTrace();
			}
			
			
			
		}
}
