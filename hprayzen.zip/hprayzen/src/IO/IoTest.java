package IO;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class IoTest {
	public static void main(String[] args) {
		
		String s = "Welcome !!!";
		
		File file = new File("C:\\Users\\old19\\OneDrive\\Desktop\\IOTest.txt")	;
		try {
		
		FileWriter fe = new FileWriter(file,true);
		
		BufferedWriter bw = new BufferedWriter(fe);
		bw.write(s+"\n");
		bw.close();
		
				
	}catch(Exception e) {
		
		e.printStackTrace();
	}
		try {
		FileReader fr = new FileReader(file);
		
		BufferedReader br = new BufferedReader(fr);
		int i=0;
		while((i= br.read() ) !=-1) {
			
			System.out.print((char)i);
			
		}

		}catch(Exception e1) {
			
			e1.printStackTrace();
		}
	
}
}