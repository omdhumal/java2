package interface1;

 class A implements Print  {

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println(a);
	}
public static void main(String[] args) {
	A a= new A();
	a.print();
	
}
	 
	 
	 
	}
	 
	 


