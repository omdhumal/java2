package interface1;

interface printable {
	void method1();

	String name = "om";

	float CGPA = 8.4f;

	void method2();

	int aa = 10;
	int bb = 20;
	int cc = aa + bb;
	
}	


	
	
	
	
	
	
		
	

