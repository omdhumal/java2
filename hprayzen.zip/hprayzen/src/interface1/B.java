package interface1;

class B implements printable {

	@Override
	public void method1() {

		// System.out.println("name\n");
		// System.out.println(CGPA);

	}

	@Override
	public void method2() {
		// TODO Auto-generated method stub

	}

	public static void main(String[] args) {

		B b = new B();
		b.method1();
		b.method2();
		System.out.println(b.name);
		System.out.println(b.CGPA);
		System.out.println(b.cc);

	}
	 
	 
	 
	
	
	
	

}






