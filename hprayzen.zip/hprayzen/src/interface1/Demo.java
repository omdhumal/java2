package interface1;

public class Demo implements Inf2 {

	public int m1(int a, int b) {

		System.out.println("m1 called from Inf1");

		return a + b;

	}

	public void m2() {

		System.out.println("m2 called from Inf2");

	}

	public String m4(String s) {
		System.out.println(s);
		return s;

	}

	public static void main(String[] args) {

		Inf2 demo = new Demo();

		// demo.m1(3, 4);
		demo.m2();
		System.out.println(demo.m1(4, 4));
		demo.m4("om");

	}

}
