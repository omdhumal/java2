package interface1;

 interface Print {
	void print();
	int a=10;
	

}
