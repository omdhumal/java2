package interface1;

public interface Inf1 {
	
	public int  m1 ( int a, int b);
	
	String m4( String str) ;
		
		
		
	
	
	
	
}

