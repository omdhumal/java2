package interface1;

public interface Inf2 extends Inf1 {
	
	public void m2();
	

}
