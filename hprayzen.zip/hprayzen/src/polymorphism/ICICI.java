package polymorphism;

public class ICICI extends Bank {

	public  float Roi() {

		System.out.println("from ICICI");
		
		return 10f;
	}

}
