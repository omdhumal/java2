package polymorphism;

public class SBI extends Bank {
	float Roi (){
		
	System.out.println("from SBI");
	return 9.5f;

	}}
