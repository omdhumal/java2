package polymorphism;

public class Bank {
//	String s= "bank";

	float Roi() {
		
		System.out.println(" From bank");
		

		return 0;
	}

}
