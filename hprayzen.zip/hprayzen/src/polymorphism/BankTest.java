package polymorphism;

import java.util.Scanner;

public class BankTest {

	public static void main(String[] args) {
		ICICI icici = new ICICI();
		
		//System.out.println(icici.Roi());


		// Bank bank = new Bank();

		// used when parameter is passed
		// System.out.println(icici.Roi(47));
		// System.out.println(icici.equals(icici));

		SBI sbi = new SBI();

		//System.out.println(sbi.Roi());

		// System.out.println(icici.equals(icici));

		// System.out.println(sbi.equals(sbi));
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Value:");
		
		long roi = sc. nextLong();
		
		String s = sc.next();
		
		System.out.println(s+" Dhumal");
	
		long si = 1000*roi;
		
		System.out.println(si);
		
	
	}

}
