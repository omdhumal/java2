package polymorphism;

public class PolyEx {
	
	void Student(int a , float b) {
		System.out.println(a+b);
	}
		
		void Student(int a, int b, int c) {
			System.err.println(a+b+c);
		}
		
		void Student( String s, int a) {
		System.out.println(s+a);
		}
		void Student(float a , int b) {
			System.out.println(a+b);
		
		
	}
		
		public static void main(String[] args) {
			PolyEx polyex=new PolyEx ();
			polyex.Student(12, 13.06f);
			polyex.Student("om", 5);
			polyex.Student(6, 70, 0);
		//	polyex.Student(12, 13);  //ocure ambiguous error bcoz of  auto promotion.

		}

}
