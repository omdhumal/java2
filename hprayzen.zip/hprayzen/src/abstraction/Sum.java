package abstraction;

abstract class Sum {
	
	public abstract int sumof2(int n1 , int n2);
	
	public abstract int  sumof3( int n1, int n2, int n3);
	
	public void m1() {
		
		System.out.println(" Non abstract method is called");
		
	}
	
	
	public void disp() {
		System.out.println("Method of class called");
		
	}	
	
}
