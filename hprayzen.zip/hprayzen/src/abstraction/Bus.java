package abstraction;

public class Bus extends Vehical {
	
	public int getnowheels() {
		
		return 6;
	}
	
	
	

}
