package abstraction;

public class VehicalTest {
	
	public static void main(String[] args) {
		Bus bus = new Bus();
		System.out.println(bus.getnowheels());
		
		Auto auto = new Auto ();
		
		System.out.println(auto.getnowheels());
	
	
	
	
	
	} 

}
