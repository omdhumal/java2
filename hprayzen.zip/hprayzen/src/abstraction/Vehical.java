package abstraction;

public abstract class Vehical {
	
	public abstract int getnowheels();
	

}




	
	

