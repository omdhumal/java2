package abstraction;

public class BikeTest {
	public static void main(String[] args) {
		Bike bike = new Honda();

		// we cant creat object of abstract class
		bike.changegear();
		bike.run();
	}

}
