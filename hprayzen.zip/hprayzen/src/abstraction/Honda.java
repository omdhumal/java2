package abstraction;

public class Honda extends Bike {
	
	void run() {
	System.out.println("Run safely");	
		
		
	}

}
