	package abstraction;

abstract class Bike {
	
	Bike(){
		System.out.println("Bike is generated");
	}
	
	abstract void run();
		
		 void changegear() {
			System.out.println("Changed gear");
			
		}
		
	}


