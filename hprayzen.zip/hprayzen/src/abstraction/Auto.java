package abstraction;

public class Auto extends Vehical {
	
	public int getnowheels() {
		
		
		return 3 ;
	}
	
	

}
