package abstraction;

public class Demo extends Sum {

	public int sumof2(int a, int b) {

		return a + b;

	}

	public int sumof3(int a, int b, int c) {

		return a + b + c;
	}

	public static void main(String[] args) {
		
		
		Demo demo = new Demo();

		System.out.println(demo.sumof2(3, 7));

		System.out.println(demo.sumof3(5, 5, 5));

		demo.disp();
		
		demo.m1();

	}

}
