package test;

public class Encaptest extends Override {

	public Encaptest(String name, String city, int mono) {
		super(name, city, mono);
	
	}
	
	public static void main(String[] args) {
		
		Override o = new Override( "om", "pune",12);
	    o.getCity();
	   
		
	System.out.println(o.toString());	
		
	}
	
	

}
