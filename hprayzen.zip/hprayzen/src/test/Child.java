package test;

public class Child extends Demo {
	
	public static void m2() {
		
	System.out.println("m2 is called");	
	}
	
	public static void main(String[] args) {
		Demo d = new Child();
		d.m1();
		//d.m2();
		
		//Child c = new Demo(); 
		
		
		
		
		
		
	}

}
