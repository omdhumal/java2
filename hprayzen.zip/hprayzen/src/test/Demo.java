package test;

public class Demo {
	
	public static  void m1() {
		
		System.out.println("m1 is called");
	}
	
	public static void main(String[] args) {
		
		m1();
		
	}

}
