 package collection;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrayLinkedList {
	
	public static void main(String[] args) {
		
		
		ArrayList list = new ArrayList();
		
		list.add("om");
		list.add(68);
		list.add("latur");
		
		ArrayList list2 = new ArrayList();
		
		list2.add("abc");
		list2.add("abc2");
		list2.add("abcd");
		
		
		for(Object s : list) {
			//System.out.println(s);
		}	
		System.out.println(list.contains(list2));
		System.out.println(list.addAll(list2));
		
		System.out.println(list);
		System.out.println(list.get(0));
		System.out.println(list.size());
		System.out.println(list.addAll(0, list2));
		
		//list.clear();
		System.out.println(list.indexOf("latur"));
		
		System.out.println(list.equals(list2));	
		System.out.println(list.get(5))  ;
			
		
	}
}


