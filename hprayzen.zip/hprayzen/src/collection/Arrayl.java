package collection;

import java.util.ArrayList;

public class Arrayl {
	public static void main(String[] args) {
		
		ArrayList al = new ArrayList();
		
		
	}

}
