package collection;

public class Student  {
  private String name ;
  private int rollno;
  private String Address;
  private long contactno;
public Student(String name, int rollno, String address, long contactno) {
	super();
	this.name = name;
	this.rollno = rollno;
	Address = address;
	this.contactno = contactno;
}
public String getName() {
	return name;
}
public int getRollno() {
	return rollno;
}
public String getAddress() {
	return Address;
}
public long getContactno() {
	return contactno;
}
public void setName(String name) {
	this.name = name;
}
public void setRollno(int rollno) {
	this.rollno = rollno;
}
public void setAddress(String address) {
	Address = address;
}
public void setContactno(long contactno) {
	this.contactno = contactno;
}
@Override
public String toString() {
	return "Student [name=" + name + ", rollno=" + rollno + ", Address=" + Address + ", contactno=" + contactno + "]";
}
  
  
  
}
