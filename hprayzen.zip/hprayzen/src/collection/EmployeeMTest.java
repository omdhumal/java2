package collection;

public class EmployeeMTest {
	
	public static void main(String[] args) {
		EmployeeM emp = new EmployeeM();
		emp.setemployeedata();
		
	}

}
