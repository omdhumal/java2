package collection;

import java.util.ArrayList;
//import java.util.HashMap;
import java.util.Collections;

public class CustomerData {
	
	public ArrayList<Custommer> setcustomerdata() {
	
		
		ArrayList<Custommer> hashmap = new ArrayList();
		
		Custommer custommer1 = new Custommer (121,"om","sbi",8393849388l);
		Custommer custommer2 = new Custommer (103,"manoj","sbi",8393849382l);
		Custommer custommer3 = new Custommer (101,"photon","sbi",8393849383l);
		Custommer custommer4 = new Custommer (100,"dhumal","sbi",8393849384l);


		hashmap.add(custommer1);
		hashmap.add(custommer2);
		hashmap.add(custommer3);
		hashmap.add(custommer4);
		
	
		CustomerData cd = new CustomerData();
		
		Collections.sort(hashmap);
		System.out.println(hashmap);
        return hashmap;
       
	}
	public static void main(String[] args) {
		CustomerData cd = new CustomerData();
		ArrayList<Custommer>  ac = cd.setcustomerdata();
		
	}

}
