package collection;

import java.security.KeyStore.Entry;
import java.util.HashMap;


public class Map {
	public static void main(String[] args) {
		
		HashMap<String , Integer> hashmap = new HashMap();
		
		hashmap.put("om", null);
		hashmap.put("manoj", 2001);
		hashmap.put("photon", 2002);
		hashmap.put("Dhumal", 2003);
		//hashmap.put(null, null);    //in hash map there is only one null key and null values willbe more then one
		//hashmap.put(null, 23);
		
		System.out.println(hashmap.containsKey("om"));
		System.out.println(hashmap.entrySet());
		System.out.println(hashmap.getOrDefault("om", 2001));
		System.out.println(hashmap.keySet());
		System.out.println(hashmap.isEmpty());
		
		
		for(java.util.Map.Entry<String, Integer>  abc : hashmap.entrySet() ) {
			
			System.out.println(abc);
			
			
			
			
			
			
		}

		
	}

}
