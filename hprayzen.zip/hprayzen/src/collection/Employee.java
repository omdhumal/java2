package collection;

public class Employee {
	private String name;
	private int age ;
	private long ContactNo;
	private long income ;
	
	
	
	public Employee(String name, int age, long contactNo, long income) {
		super();
		this.name = name;
		this.age = age;
		ContactNo = contactNo;
		this.income = income;
	}
	
	
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public long getContactNo() {
		return ContactNo;
	}
	public long getIncome() {
		return income;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setContactNo(long contactNo) {
		ContactNo = contactNo;
	}
	public void setIncome(long income) {
		this.income = income;
	}
	
	
	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + ", ContactNo=" + ContactNo + ", income=" + income + "]";
	}
	
	
	
	

}
