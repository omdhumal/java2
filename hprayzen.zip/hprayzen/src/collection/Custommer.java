package collection;

public class Custommer implements Comparable<Custommer> {
	
	private int Acno; 
	private String Name;
	private String bankname;
	private Long mobilenumber;
	
	
	public Custommer(int acno, String name, String bankname, Long mobilenumber) {
		super();
		Acno = acno;
		Name = name;
		this.bankname = bankname;
		this.mobilenumber = mobilenumber;
	}
	public int getAcno() {
		return Acno;
	}
	public String getName() {
		return Name;
	}
	public String getBankname() {
		return bankname;
	}
	public Long getMobilenumber() {
		return mobilenumber;
	}
	public void setAcno(int acno) {
		Acno = acno;
	}
	public void setName(String name) {
		Name = name;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	public void setMobilenumber(Long mobilenumber) {
		this.mobilenumber = mobilenumber;
	}
	
	@Override
	public String toString() {
		return "Custommer [Acno=" + Acno + ", Name=" + Name + ", bankname=" + bankname + ", mobilenumber="
				+ mobilenumber + "]";
	}
	
	
	@Override
	public int compareTo(Custommer o) {
		/*if(Acno> o.getAcno()) {
			
			return 1;}
		
		else if(Acno< o.getAcno()){
			
			return -1;
		}
			else {
				
				return 0;
			}*/
		
		
		return Name.compareToIgnoreCase(o.getName());
		
	}
}
	

	


	
		
	
	
