package collection;

import java.util.LinkedHashMap;

public class LinkedHashMapEx {
	public static void main(String[] args) {
		
		LinkedHashMap lhm = new LinkedHashMap();
		
		lhm.put("abc1", "pune1");
		lhm.put("abc2", "pune2");
		lhm.put("abc3", "pune3");
		lhm.put("abc4", "pune4");
		
		//System.out.println(lhm.putIfAbsent("abc1", "lhm"));
		
		//System.out.println(lhm.getOrDefault("abc4","pune"));
		
		System.out.println(lhm.entrySet());

		
		
		
		
	}

}
