package collection;

import java.util.LinkedList;
import java.util.List;

public class EmployeeM {
	
	private String name;
	private int age;
	private long ContactNo ;
	private int income;
	
	
	public EmployeeM(String name, int age, long contactNo, int income) {
		super();
		this.name = name;
		this.age = age;
		ContactNo = contactNo;
		this.income = income;
	}
	
	public EmployeeM() {
	
	}
	
	public void setemployeedata() {
		
		LinkedList<EmployeeM> list  = new LinkedList ();
		
		
		EmployeeM emp1 = new EmployeeM("anuj",22,8182888888l,20000);
		EmployeeM emp2 = new EmployeeM("asha",23,8182888889l,30000);
		EmployeeM emp3 = new EmployeeM("ingale",24,8182888887l,40000);
		EmployeeM emp4 = new EmployeeM("rutu",21,8182888886l,50000);
		
		list.add(emp1);
		list.add(emp2);
		list.add(emp3);
		list.add(emp4);
		
		System.out.println(list);
		
	}

	@Override
	public String toString() {
		return "EmployeeM [name=" + name + ", age=" + age + ", ContactNo=" + ContactNo + ", income=" + income + "]";
	}

	
	
	
		
	
	
	

}
