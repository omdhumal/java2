package collection;

import java.util.LinkedList;

public class LinkedListEx {

	public static void main(String[] args) {
		
		
	LinkedList list  = new LinkedList();
	
	list.add("om");
	list.add("abc");
	list.add("xyz");
	list.add("str");
	
	
	
LinkedList list2  = new LinkedList();
	
	list2.add("manoj");
	list2.add("abcd");
	list2.add("xyz");
	list2.add("Pune");
	
	
	//System.out.println(list.retainAll(list2));
//	System.out.println(list);
	
	System.out.println(list.subList(0, 3));
	
	
	
		
	
		
	}
}
