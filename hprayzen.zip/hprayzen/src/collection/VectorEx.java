package collection;

import java.util.Vector;

public class VectorEx {
	public static void main(String[] args) {
		
		Vector v = new Vector ();
		
		v.add("ram");
		v.add("rom");
		v.add("processor");
		v.add("battery");
		
		Vector v1 = new Vector ();
		
		v1.add("wt");
		v1.add("Display");
		v1.add("Brand ");
		v1.add("camera");
		v1.add("fast charging");

		
		v.add(v1);
		//System.out.println(v);
		
		
	}

}
