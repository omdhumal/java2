package collection;

import java.util.ArrayList;
import java.util.List;

public class Employee2 {
	
	public static void main(String[] args) {
		
		TestEmployee te = new TestEmployee();
		
		//List<Employee> list = new ArrayList<>();
		
		te.setEmployeeData();

		
	}

}
