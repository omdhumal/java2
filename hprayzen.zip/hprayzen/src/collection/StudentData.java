package collection;

import java.util.ArrayList;
import java.util.Collections;

public class StudentData {
	
	public ArrayList<Student> setstudentdata() {
		
		ArrayList<Student> list = new ArrayList();
		
		
		Student student1 = new Student("om",22,"pune",72727272772l);
		Student student2 = new Student("manoj",20,"nilanga",72727272772l);
		Student student3 = new Student("photon",23,"latur",72727272772l);
		Student student4 = new Student("Dhumal",21,"bombay",72727272772l);
		
		list.add(student1);
		list.add(student2);
		list.add(student3);
		list.add(student4);

    /*   Student1 st1 = new Student1();
		Collections.sort(list, new Student1());*/
		
		
		Collections.sort(list, new Student2());
		
		return list;
		
	}
	public static void main(String[] args) {
		StudentData sd = new StudentData();
	ArrayList<Student> asa	=sd.setstudentdata();
	System.out.println(asa);

		
	}

}
