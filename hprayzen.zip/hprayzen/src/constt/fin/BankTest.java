package constt.fin;

public class BankTest {
	
	
	
	
	public void m1() {

		Bank bank = new Bank(123456789, "om" , "nilanga", "Latur") ;
		
/*	bank.getAcno();
	bank.getName();
	bank.getCity();
	bank.getBranch();*/
	
	System.out.println(bank.getAcno());
	System.out.println(bank.getBranch());
	System.out.println(bank.getName());
	System.out.println(bank.getCity());
		
	}
	
	
	
	public static void main(String[] args) {
		
		BankTest banktest = new BankTest();
		 
		banktest.m1();
		

		
		
	}

}
