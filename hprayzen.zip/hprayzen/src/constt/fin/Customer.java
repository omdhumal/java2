package constt.fin;

public class Customer {
	
	private  final int  customerId ;
	private String customerName;	
	private int customerNo;
	
	

	
	public Customer(int customerId, String customerName, int customerNo) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerNo = customerNo;
		
		
		
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(int customerNo) {
		this.customerNo = customerNo;
	}
	public int getCustomerId() {
		return customerId;
	}
	
	
	
}