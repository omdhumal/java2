package constt.fin;

public class CustomerTest {

	public Customer m1() {
		Customer customer = new Customer(18181818, "om", 76543210);

		return customer;

	}

	public void m3() {

		Customer customer = m1();

		customer.setCustomerName("student");
		customer.setCustomerNo(454454);

		System.out.println(customer.getCustomerId());
		System.out.println(customer.getCustomerName());
		System.out.println(customer.getCustomerNo());

	}

	public static void main(String[] args) {

		CustomerTest customertest = new CustomerTest();
		customertest.m3();

	}
}
