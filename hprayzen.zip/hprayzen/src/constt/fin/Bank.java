package constt.fin;

public class Bank {
private final double Acno;
 private String Name ;
 private String Branch;
 private String City;
 
 
 
 
 
public Bank(double acno, String name, String branch, String city) {
	super();
	Acno = acno;
	Name = name;
	Branch = branch;
	City = city;
}




public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getBranch() {
	return Branch;
}
public void setBranch(String branch) {
	Branch = branch;
}
public String getCity() {
	return City;
}
public void setCity(String city) {
	City = city;
}
public double getAcno() {
	return Acno;
}
 
 
 
 
	
	
	

}
