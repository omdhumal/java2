package wrpclass;

public class Int {

	int a = 20;
	Integer i = a;  
	short c = 2;
	Short s = c;
	boolean b = true;
	
	

	public void m1() {
		Integer i = a;
		

		
		System.out.println(i+s);
		System.out.println(b);

	}

	public static void main(String[] args) {

		Int inta = new Int();
		 System.out.println(inta.i);
		 inta.m1();
		
	}

}
