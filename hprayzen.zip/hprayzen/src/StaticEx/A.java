package StaticEx;

public class A {

	static int aa;
	String str;

	static {

		int aa = 10;

		System.out.println("static called "+aa);

	}

	{
		int aa = 50;

		System.out.println("instance called"+aa);
	}

	 

	public  A() {
		
		 aa= 29;
		System.out.println(aa);
	
	}



	public static void main(String[] args) {
		A a = new A();
		//a.A();
		
		int c =A.aa;
		System.out.println(c);
	}

}

