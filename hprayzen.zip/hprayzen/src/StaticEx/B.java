package StaticEx;

public class B {
	
	public static void main(String[] args) {
		A a= new A();
		System.out.println(a.aa);
		
		
		
		//System.out.println(a.);
	
	}

}
