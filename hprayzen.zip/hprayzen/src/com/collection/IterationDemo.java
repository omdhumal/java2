package com.collection;

import java.util.Iterator;
import java.util.LinkedList;

public class IterationDemo {

	public static void main(String[] args) {
		
		LinkedList ll = new LinkedList();
		ll.add(1);
		ll.add(2);
		ll.add(3);
		ll.add(4);
		ll.add(5);
		ll.add(6);
		
		
		Iterator it = ll.descendingIterator();
		
		while(it.hasNext()) {
		System.out.println(it.next());
		}
		
		Iterator it1 = ll.descendingIterator();

		Integer e = (Integer)it1.next();
		if( e==7) {
			it1.remove();
			
		}
		
    	System.out.println(ll);
		
		
	}
}
