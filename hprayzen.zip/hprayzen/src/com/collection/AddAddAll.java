package com.collection;

import java.util.ArrayList;

public class AddAddAll {
	
	public static void main(String[] args) {
		
		ArrayList al = new ArrayList();
		
		al.add("all");
		al.add("is");
		al.add("well!");
		
		
		ArrayList al2 = new ArrayList ();
		
		al2.add("AAl");
		al2.add("Izz");
		al2.add("Well!");
		
		al.addAll(al2);
		
		
		System.out.println(al);
		System.out.println(al.contains("all"));
		System.out.println(al.isEmpty());
		System.out.println(al.size());
		System.out.println(al.remove("all"));
		
		
	}

}
