package com.thread;

public class TestI extends Thread {

	
	public void run() {
		System.out.println("A:"+Thread.interrupted());  // it changes the status from true to false
		//System.out.println("B:"+Thread.interrupted());
		//now here the interrupted changes the status to false so, isInterrupted give false output.
		
		
		System.out.println("D:"+Thread.currentThread().isInterrupted());//it does not changes the status always give same output
		//System.out.println("E:"+Thread.currentThread().isInterrupted());


		
		
		try {
			for(int i=1;i<=5;i++) {
				Thread.sleep(1000);
				System.out.println(i+":"+Thread.currentThread().getName());
			}
		}catch(Exception e) {
			
			System.out.println("Thread intrupted"+e);
		}
		
	} 
	public static void main(String[] args) {
		TestI te = new TestI();
		te.start();
		te.interrupt();
		
	}
	

}
