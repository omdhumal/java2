package com.thread;

public class Thread2 implements Runnable {
	
	public void run () {
		
		System.out.println("threaad task");
	}
     public static void main(String[] args) {
	
    	 Thread2 t = new Thread2();
    	 Thread th = new Thread(t);

    	 th.start();
	
	
	
}
}
