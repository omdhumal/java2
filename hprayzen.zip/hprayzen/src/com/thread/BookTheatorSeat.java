package com.thread;

public class BookTheatorSeat {
	
	int totalseat=10;
	
  void bookseat(int seat) {
	
    	if(totalseat>=seat) {
    		
    		System.out.println("seats are booked :"+seat);
    		
    		totalseat= totalseat - seat;
    		System.out.println("seats left :"+totalseat);
    	}
    	else {
    		System.out.println("sorry we cant book");
    		System.out.println("Available number of seats are :"+totalseat);
    	}
	
	
}

}
