package com.thread;

public class ThreadJ extends Thread {

	public void run() {
		try {
			for (int i = 1; i <= 5; i++) {
				Thread.sleep(1000);

				System.out.println("child thread:" + i);

			}
		}

		catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) throws InterruptedException {
		ThreadJ tj = new ThreadJ();
		tj.start();
		tj.join();

		try {
			for (int i = 1; i <= 5; i++) {

				Thread.sleep(1000);

				System.out.println("main method" + i);
			}
		} catch (Exception e) {
			System.out.println(e);

		}

	}

}
