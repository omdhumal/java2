package com.thread;

public class TestTotalEarning {
	
	public static void main(String[] args) throws InterruptedException{
		
		
		TotalEarning te= new TotalEarning();
		te.start();
		
		//System.out.println("total earning:" +te.totale);
		
		synchronized(te) {
			
			te.wait();
			System.out.println("Total earrning :"+te.totale);
		}
		
	}

}
