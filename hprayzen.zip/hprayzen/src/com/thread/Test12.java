package com.thread;

public class Test12 extends Thread {
	public void run () {
		
		System.out.println("multitasking from multiple methods Test 12");
	}

}
