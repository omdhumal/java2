package com.thread;

public class TestD extends Thread {
	
	public void run () {
		
		if(Thread.currentThread().isDaemon()) {
		
		System.out.println("Deamon thread :");
		
		}
		
		else {
			
			System.out.println("child threaad ");
		}
	}
    public static void main(String[] args) {
    	
    System.out.println("Main Thread");
    	
    	TestD td = new TestD ();
    	
    	td.setDaemon(true);
    	
    	td.start();
    	
	
}
}
