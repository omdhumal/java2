package com.thread;

public class Test extends Thread {
	
	public void run () {
		
		System.out.println("single task  by multiple thread ");
		
	}public static void main(String[] args) {
		
		Test t =  new Test  ();
		t.start();
		
		Test t2 = new Test ();
		t2.start();
		
		Test t3 = new Test ();
		t3.start();
	}
	
	

}
