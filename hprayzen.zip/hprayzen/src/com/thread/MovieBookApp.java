package com.thread;

public class MovieBookApp extends Thread {
	static BookTheatorSeat b ;
	int seat;
	public void run() {
		b.bookseat(seat);
	
		
	}
	
	synchronized public static void main(String[] args) {
		
		 b = new BookTheatorSeat();
		Thread.currentThread().setPriority(MAX_PRIORITY);
		MovieBookApp m = new MovieBookApp();
	//	m.seat=7;
		m.start();
		
		
		
		MovieBookApp m2 = new MovieBookApp();
		Thread.currentThread().setPriority(4);

		m.seat=26;
		m2.start();
		
		MovieBookApp m3 = new MovieBookApp();
		m3.seat = 6;
		m3.start();
	}

}
