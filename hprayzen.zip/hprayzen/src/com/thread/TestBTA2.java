package com.thread;

public class TestBTA2  extends Thread{
	int seats;
	BookTheatorApp bta2;
	
	void myThread(BookTheatorApp bta2, int seats) {
		
		this.bta2=bta2;
		this.seats=seats;
		
	}
	
	public void run() {
		bta2.bookseat(seats);
		
		
	}
	public static void main(String[] args) {
		
		BookTheatorApp bta2 = new BookTheatorApp();
		
		TestBTA2 bt2  = new TestBTA2 ();
		bta2.bookseat(4);
		bt2.start();
		
		
		BookTheatorApp bta3 = new BookTheatorApp();
		bta3.bookseat(1);
		bt2.start();
		
		
		
		
		
	}

}
