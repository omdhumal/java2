package com.thread;

public class TotalEarning extends Thread{
	
	int totale=0;
	public void run() {
		
		
		synchronized(this) {
		
		for (int i=1;i<=10;i++) {
			
			totale = totale + 100;
			
		}
		
		this.notify();
	}

}
}