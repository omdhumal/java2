package com.thread;

public class TestP extends Thread  {
	
	public void run() {
		
		System.out.println("child priority is priority is: " +Thread.currentThread().getPriority());
		
		
	}
  public static void main(String[] args) {
	
	  System.out.println("main thread old priority: "+Thread.currentThread().getPriority());
	  
	  Thread.currentThread().setPriority(6);
	  System.out.println("main thread new priority is: "+Thread.currentThread().getPriority());
	  
	  
	  TestP tp =new TestP();

	  tp.setPriority(3);
	  
	  tp.start();
	
	
}
}
