package com.thread;

public class BookTheatorApp {
	
	static int total_seats= 20;
	
	static synchronized  void bookseat(int seats ) {
		 
		 BookTheatorApp bta = new BookTheatorApp();
		 
		 
		     
		 if(total_seats >=seats ) {
			 
			System.out.println("seats Booked:" +seats); 
			
			total_seats = total_seats- seats;
			
			System.out.println("seats left:"+total_seats);
			 
		 }
		 else {
			 System.out.println("Sorry , seats  can't book");
			 
			 System.out.println("Seats available are"+total_seats); 
		 }
		

		 
		 
		 
	 }
	 
	 
	
	

}
