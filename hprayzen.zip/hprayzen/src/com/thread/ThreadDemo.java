package com.thread;

public class ThreadDemo extends Thread  {
	
	public void run()  {
		try {
		
		for(int i=1;i<=5;i++) {
		
			System.out.println(i+ ":"+Thread.currentThread().getName());
			Thread.sleep(1000);

		}
		
		}catch(Exception e) {
			System.out.println(e);
		}
		}

	
	public static void main(String[] args) {
		ThreadDemo td = new ThreadDemo ();  // if you use run instid of start then 10 sec will take time
		td.start();
		for(int i=1;i<=5;i++) {
			
			System.out.println(i+" :" +Thread.currentThread().getName());
			
		}
		ThreadDemo t2 = new ThreadDemo();
		t2.start();
		
		
		
		
	}

}
