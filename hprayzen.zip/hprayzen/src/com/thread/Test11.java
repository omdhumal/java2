package com.thread;

import java.security.DomainCombiner;

public class Test11 extends Thread {
	
	public void run () {
		
		System.out.println("multitasking from multiple method Test 11");
		
		for(int i=1;i<=5;i++) {
			
			System.out.println(i);
			
		}
		
		
	
		
		
		
		
	}
	

}
