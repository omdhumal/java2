package com.thread;

public class TestM extends Thread  {
	
	public void run() {
		
		System.out.println("multitasking at Testm");
		
		int a = 10;
		int b= 20 ;
		System.out.println(a+b);
	}
	
	
	
	public static void main(String[] args) {
	//Thread.currentThread().setPriority(1);
		Test11 t1 = new Test11 ();
		Thread.currentThread().setPriority(4);
		t1.start();
		
		
		
		//Thread.currentThread().setPriority(2);
		Test12 t2 = new Test12();
		Thread.currentThread().setPriority(2);

		t2.start();
		
		
	//	Thread.currentThread().setPriority(3);
		TestM tm = new TestM();
		
		Thread.currentThread().setPriority(3);

		tm.start();
		
		
		
	}

}
