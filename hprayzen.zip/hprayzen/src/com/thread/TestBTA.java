package com.thread;

public class TestBTA extends Thread {
	int seats;
	BookTheatorApp bta;
	
	public void run() {
		
		//bta.bookseat(seats);
		
	}
	public static void main(String[] args) {
		BookTheatorApp bta = new BookTheatorApp();
		TestBTA b = new TestBTA();
		bta.bookseat(7);
		b.start();
		
		TestBTA b2 = new TestBTA();
		bta.bookseat(3);
		b2.start();
		
		
		
		
		
	}

}
