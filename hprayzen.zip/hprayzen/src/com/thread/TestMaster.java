package com.thread;

public class TestMaster  {
	
	public static void main(String[] args) {
		
		BookTheatorApp bta = new BookTheatorApp();
		
		TestBTA bt1 = new TestBTA();
		bt1.start();
		bta.bookseat(5);
		
		TestBTA bt2 = new TestBTA();
		bt2.start();
		bta.bookseat(10);
		
		
		TestBTA2 bt3 = new TestBTA2();
		bt3.start();
		bta.bookseat(7);
		
		TestBTA2 bt4 = new TestBTA2();
		bt4.start();
		bta.bookseat(2);
		
	}

}
