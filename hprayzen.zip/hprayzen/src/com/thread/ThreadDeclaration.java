package com.thread;

public class ThreadDeclaration extends Thread {
	
	public void run() {
		
		System.out.println("Thread task");
		
	}
	
	public static void main(String[] args) {
		ThreadDeclaration t = new ThreadDeclaration();
		
		t.start();
		
		
		
		
	}

	
	
	
}
