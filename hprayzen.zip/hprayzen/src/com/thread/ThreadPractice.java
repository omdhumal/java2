package com.thread;

public class ThreadPractice extends Thread{
	public void run() {
		System.out.println("Child method");
		try {
			Thread.yield();

			for (int i = 1; i <= 5; i++) {
				Thread.sleep(1000);
				// Thread.yield();
				System.out.println(i + ":" + Thread.currentThread().getName());
			}

		} catch (Exception e) {
			System.out.println("Exception handled :");

		}

	}

	public static void main(String[] args) throws Exception {
		ThreadPractice tp = new ThreadPractice();

		tp.start();
		// tp.join();

		Test11 t1 = new Test11();

		// Thread.yield();

		t1.start();
		try {
			t1.join();
		} catch (Exception e) {
			System.out.println("Exception handle");
		}
	}

}
