package array.com;

public class ArrayDemo {
	public static void main(String[] args) {
		int[] a = {10,20,30};
		int x = 10;
		int y= -10;
		
		System.out.println(~x);
		System.out.println(~y);
		System.out.println(x+ + x);
		
		
		for(int i=0;i<a.length;i++) {
			//System.out.println(a[i]);
			
		}
		for(int j:a) {
			//System.out.println(j);
		}
	}

}
