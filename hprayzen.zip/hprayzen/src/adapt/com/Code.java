package adapt.com;

public class Code<Address> {
	private int userId;
    private String email;
    private String password;
    private String firstName;
    private String lastName;
    private String city;
    private String gender;
    private long phoneNumber;
    private Address address;
	@Override
	public String toString() {
		return "Code [userId=" + userId + ", email=" + email + ", password=" + password + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", city=" + city + ", gender=" + gender + ", phoneNumber=" + phoneNumber
				+ ", address=" + address + "]";
	}
    
	

}
