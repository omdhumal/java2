package adapt.com;

import java.util.Arrays;

public class Dimensional2 {
	public static void main(String[] args) {
		int [][] nums = new int  [3][];
		nums[0]= new int[] {24,45,78};
		nums[1]= new int[6];
		nums[2]= new int [] {12,100,200};
		
		
		System.out.println(nums.length);
		for(int i=0;i<=nums.length-1;i++) {
		System.out.println(Arrays.toString(nums[i]));
		for(int[] num: nums) {
			System.out.println(nums[i]);
			
		}
	}}
	

}
