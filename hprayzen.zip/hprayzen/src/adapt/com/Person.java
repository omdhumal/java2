package adapt.com;

public class Person {
	private String firstname;
	private String lastname;
	private String city;
	
	public Person() {
		
	}

	public Person(String firstname, String lastname, String city) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.city = city;
	}

	@Override
	public String toString() {
		return "Person [firstname=" + firstname + ", lastname=" + lastname + ", city=" + city + "]";
	}
	

}
