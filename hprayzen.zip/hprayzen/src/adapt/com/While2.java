package adapt.com;

public class While2 {
	
	public static void main(String[] args) {
		int a,b,c;
		a=-1;
		b=1;
		int limit = 100;
		while(true) {
			c=a+b;
			if(c>100) {
				break;
			}
			System.out.println(c);
			a=b;
			b=c;
			
		}
		
	}

}
