package adapt.com;

public class While {
	
	public static void main(String[] args) {
		
		int num=29;
		int i=1;
		while(true) {    // instid of true and if stmt use i<=10
			
			System.out.printf("%d*%d = %d \n",num,i,num*i);
			i++;
		if(i>10) {
			break;
		}
			
		}
		System.out.println("end of demo");
		
	}

}
