package adapt.com;

public class Array {
	public static void main(String[] args) {
		int[] nums = {10,20,45,76};
		System.out.println("nums=" +nums);
		System.out.println(("numbers contain " +nums.length +" integers"));
		for(int i=0;i<=nums.length-1;i++) {
			System.out.println(nums[i]);
		}
	}

}
