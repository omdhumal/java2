package adapt.com;

import java.util.Scanner;

public class ForLoop {
	
	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		int num ;
	    System.out.println("Enter int num:");
	    num = sc.nextInt();
	    
	    boolean isprime = true;
	    
	    for (int i = 2 , limit = num/2 ;i<=limit; i++ ) {
	    	
	    	if ( num%i==0) {
	    		isprime= false;
	    		break;
	    	}
	    }
	    if(isprime) {
	    	System.out.println(num+ "is prime number.");
	    }
	    else {
	    	
	    	System.out.println(num+ " is not prime number");
	    }
		sc.close();
	}
	

}
