package adapt.com;

public class Triangle extends Shape {
	private double base;
	private double height;

	public Triangle() {
		
	}

	public Triangle(double base, double height) {
		super();
		this.base = base;
		this.height = height;
	}
	@Override
	public void info() {
		System.out.printf("Object of Triangle with base=%s and height=%s", base,height);
		
	}
	
	@Override
	public void printarea() {
		System.out.printf(":Area of trianle is", 
				0.5*base*height);
	}
	

	
}
