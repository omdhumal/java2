package adapt.com;

import java.util.Scanner;

public class ScannerDemo {
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number:");
		
			
		if(sc.hasNextInt()) {
			int num = sc.nextInt();
			
		
		System.out.println("You Entered :"+num);
	}else {
		System.out.println("you entered wrong number:");
		
		
	}}

}
