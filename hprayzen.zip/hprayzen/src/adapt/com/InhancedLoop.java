package adapt.com;

import java.util.Arrays;
import java.util.List;

public class InhancedLoop {
	public static void main(String[] args) {
		
	String []	names  = { "ganesh" ,"mariam", "Utkarsha" , "vedant", "noman" , "Shubhada", "om", "Ankita"};
	
	List<String> list = Arrays.asList(names);
	
	for(String name : names) {
		System.out.println("hello "+name);
	}
		
	for(String name1:list) {
		System.out.println("Welcome back"+name1);
	}
		
		
	
			
	}
		
	

}
