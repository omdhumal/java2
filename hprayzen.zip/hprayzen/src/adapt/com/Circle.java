package adapt.com;

public class Circle extends Shape{
	
	private double radius;
	
	public Circle() {
	}
	

	public Circle(double radius) {
		super();
		this.radius = radius;
	}


	public double getRadius() {
		return radius;
	}


	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	@Override
	public void printarea() {
		System.out.println("area of circle is "+ Math.PI*radius*radius+ "sq.units");
		
	}
	public void info() {
		System.out.println("A circle object wit  " +radius+ " units");
	}
	
	

}
