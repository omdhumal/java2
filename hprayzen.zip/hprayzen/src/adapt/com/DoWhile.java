package adapt.com;

import java.util.Scanner;

public class DoWhile {
	
	static boolean isprime(int num) {
		for(int i=2,limit = num/2;i<=limit; i++) {
			if(num%i==0) {
				return false;
				}
		}
		
		return true;
		
	}
	
	public static void main(String[] args) {
		Scanner sc;
		String yesno;
		do {
		
		 sc = new Scanner(System.in);
		System.out.println("Enter The Number: ");
		int  num=sc.nextInt();
		
		if(isprime(num)) {
			System.out.println( +num+" is prime number.");
		}else {
			System.out.println(+num+ "number is not prime number");
		}
		sc= new Scanner(System.in);
		System.out.println("do you want try again? Enter yes/no:");
		yesno=sc.nextLine();
		
		}while(yesno.equalsIgnoreCase("yes"));	
	}

}
