package adapt.com;

public class code2 {
	 private String city;
	    private String state;
	    private int zip;
	    private String country;
		@Override
		public String toString() {
			return "code2 [city=" + city + ", state=" + state + ", zip=" + zip + ", country=" + country + "]";
		}
	    
	    
	    
	    
	    

}
