package adapt.com;

public class Shape {
	public void info() {
		System.out.println("just a shape");
		
	}
	public void printarea() {
		System.out.println("can't print area");
	}

}
