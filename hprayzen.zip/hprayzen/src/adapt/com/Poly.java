package adapt.com;

public class Poly {
	public static void main(String[] args) {
		Shape s1;
		s1=new Shape();
		s1.info();
		s1.printarea();
		System.out.println();
		s1 = new Circle(12.34);
		s1.info();
		s1.printarea();
		System.out.println();
		s1=new Triangle(5.34,10.13);
		s1.info();
		s1.printarea();
		
				
		
		
		
	}

}
