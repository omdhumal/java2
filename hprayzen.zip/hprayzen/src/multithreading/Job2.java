package multithreading;

public class Job2 extends Thread {
	
	public void run() {
		System.out.println(Thread.currentThread().getName());
		
		for(int i=11;i<=20;i++) {
			
			System.out.println(i);
		}
	}

}
