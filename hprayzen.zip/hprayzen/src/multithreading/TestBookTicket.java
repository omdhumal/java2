package multithreading;

public class TestBookTicket extends Thread {
	
	public void run() {
	
		
		
	}
	public static void main(String[] args) {
		
	
		
		BookTicket bt = new BookTicket();
         bt.start();
         
         
		
	}
}
