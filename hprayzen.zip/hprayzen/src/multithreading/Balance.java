package multithreading;

public class Balance extends Thread{
	
	static int balance = 10000;
	static int withdraw = 1500;
@Override
	public void run() {
	Balance bb = new Balance ();
      bb.W1();
		
	}
	 static synchronized public void W1() {
	
		
		for (int i = 1;i<=10;i++) {
			System.out.println(Thread.currentThread().getName());

	
	if(balance >= withdraw) {
		balance = balance-withdraw;

		System.out.println("balance withdraw:"+withdraw);
		balance = balance-withdraw;
		System.out.println("balance available:"+balance);
		
		
	}else {
		
		System.out.println("insufficient balance :"+balance);
	}
		}
	
		
		
	}


}