package multithreading;

public class Testwithdraw extends Thread{
	
	@Override
	public void run() {
		
		
	}
	public static void main(String[] args) {
		
		Balance b1 = new Balance();
		b1.start();
	
		Balance b2 = new Balance();

		b2.start();
		
	}

}
