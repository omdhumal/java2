package multithreading;

public class RunnableEx  implements Runnable{
	
	public void run() {
		for(int i=1;i<=10;i++) {
		
		System.out.println(i);
	}
		
	}
	
	public static void main(String[] args) {
		RunnableEx re = new RunnableEx();
		Thread t = new Thread(re);
		t.start();
	}
}
