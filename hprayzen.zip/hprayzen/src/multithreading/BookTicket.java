package multithreading;

public class BookTicket extends Thread  {
	
	
	public void run() {
		BookTicket bt = new BookTicket();
		bt.pasenger1();
		
	}
	
	public void pasenger1() {
		
		System.out.println("book seat for p1:");
		
		
		
	}
	
	public void pasenger2() {
		
		System.out.println("book seat for p2");
	}
	
	
	public static void main(String[] args) {
		
	}

}
