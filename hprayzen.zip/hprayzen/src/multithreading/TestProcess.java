package multithreading;

public class TestProcess {
	public static void main(String[] args) {
		Process p = new Process();
		Thread t1 = new Thread(new Runnable() {
			
		
			public void run() {
				p.test1();
				
	
			}
		
	});
		
		t1.start();
		
		
	Thread t2 = new Thread(new Runnable() {
		
		public void run() {
			p.test2();
			
			
		}
		
	});
	t2.start();
	
		
		
		
		
	} 	
}
