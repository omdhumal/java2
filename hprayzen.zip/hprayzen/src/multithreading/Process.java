package multithreading;

public class Process {

	public void test1() {

		System.out.println("test thread 1:" + Thread.currentThread().getName());

		synchronized (this) {
			try {
				wait();
			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}

		System.out.println("Thread resumed:" + Thread.currentThread().getName());
	}

	public void test2() {

		System.out.println("before Thread:" + Thread.currentThread().getName());
		synchronized (this) {
			try {
				notify();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println("after Thread:" + Thread.currentThread().getName());
	}
}
