package multithreading;

public class StringThread extends Thread {
	
	public void run() {
		
		String[] s = {"a1","b2","c3","dd4","e5","f6","g7","8","i9","j10","k11","l12"}; 
	
		for(char i=0;i<=s.length-1;i++) {

			System.out.println(s[i]);
	}
	
	}
	
	public static void main(String[] args) {
		//System.out.println(Thread.currentThread().getName());
	//	StringThread st = new StringThread();
	//	st.start();
		
		
		StringThread st1 = new StringThread();
		Thread.currentThread().setName("ThreadNAme");
		System.out.println(Thread.currentThread().getName());

		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		st1.start();

		
	}

}
