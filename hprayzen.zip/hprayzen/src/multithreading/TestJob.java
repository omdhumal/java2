package multithreading;

public class TestJob {
	
	public static void main(String[] args) {
		
		
		System.out.println(Thread.currentThread().getName());
		for(int i=51;i<=60;i++) {
			
			System.out.println(i);
		}
		Job1 j1 = new Job1();
		try {
		
		Thread.sleep(1000);
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		j1.start();
		
		Job2 j2 = new Job2();
		j2.start();
		
		System.out.println(Thread.currentThread().getName());
		for(int i=21;i<=30;i++) {
			
			System.out.println(i);
		}
	}

}
