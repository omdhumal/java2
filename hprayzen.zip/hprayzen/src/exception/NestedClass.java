package exception;

public class NestedClass {
	public static void main(String[] args) {
		
	try {
		
		try {
			
		System.out.println(" Going to divided by 0");	
			
		int a = 48/0;
		
		System.out.println(a);	
			
		}catch(ArithmeticException e) 
		
		{		
		System.out.println(e);	
			
		}
		
		try {
			
		 //   int c[]=new int[5];    
		    
		    
		//     c[5]=4;   
		     
		     
		  int f[]=new int [4];
		  
			f[4] = 2;

		} catch (ArrayIndexOutOfBoundsException e) {

			System.out.println(e);

		}

		System.out.println("new statement");

	} catch (Exception s) {

		System.out.println("handle the exception");

	}finally {
		
		
		System.out.println("finally block always executed");
	}

	System.out.println("continue the flow");

}
}
