package exception;

public class ExceptionTest {  
	
	
public int m1(int a , int b) {
	
	
	System.out.println("logic");
	int div = 0;
	
	try {
	div = a/b;
	
		System.out.println("exception :::"+div);	
	
	}catch(NullPointerException  e) {
		
		System.out.println("error");
		
		
	}catch(Exception e) {
		
	System.out.println("superclass called");	
		
		
		
	}
	
	return div;
	
	
	  
}

public static void main(String[] args) {

	ExceptionTest exptest = new ExceptionTest();
	int c= exptest.m1(20,0);
	System.out.println(c);
	
	System.out.println("remaining code");
	
	
}


}

	
	
	


