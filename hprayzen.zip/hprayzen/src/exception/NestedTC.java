package exception;

public class NestedTC {

	public static void main(String[] args) {
		System.out.println("before outer try catch");

		try {
			System.out.println("in outer try ");
			try {
				System.out.println("in inner try :");
				System.out.println(20 / 0);
			} catch (NullPointerException e) {

				System.out.println("in inner catch:");

			}

		} catch ( Exception a) {

			System.out.println("in outer catch:");

		}

	}

}
