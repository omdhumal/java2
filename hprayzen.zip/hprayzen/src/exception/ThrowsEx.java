package exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterInputStream;

public class ThrowsEx {
	
	
	void read() throws FileNotFoundException {
		
		FileInputStream  fis = new  FileInputStream("d:/abc.t");
		
	}
	
	void save() throws FileNotFoundException {
		String text = "This is Demo";
		FileOutputStream fos = new FileOutputStream("d:/xyz.t");
	
	}
		public static void main(String[] args) {
			
			ThrowsEx te = new ThrowsEx();
			try {
			
			te.read();
			te.save();
			
		}catch(FileNotFoundException fe) {
			
			
			System.out.println("Exception handled");
		}
		
		
		
		
	}
}

