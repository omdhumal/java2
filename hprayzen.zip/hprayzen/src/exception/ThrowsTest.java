package exception;

import java.io.IOException;

public class ThrowsTest {

	void m() throws IOException {

		System.out.println("Excepton throws");
	}

	void p() throws IOException {

		m();
		System.out.println("exception throws from p");
	}

	void o() {
		try {

			m();

		} catch (Exception e) {

			System.out.println(" Exception handle ");

		}
		
	}
	
	
	public static void main(String[] args) {
		
		ThrowsTest tt = new ThrowsTest();
		tt.o();
		
		System.out.println("Exception handled");
		
		
		
	}
		
		

}

