package exception;

public class NestedTCF {
	
	
	public static void main(String[] args) {

		try {
			System.out.println("outer try1");
			System.out.println("outer try2");
			System.out.println("outer try3");

			try {
				System.out.println("inner try4" + (10 / 0));
			} catch (ArithmeticException e) {
				System.out.println("inner catch5");
			} finally {
				System.out.println("inner finally6" + (10 / 0));
			}

			System.out.println("statment7");

		} catch (Exception r) {
			try {
				System.out.println("outer catch8" + (10 / 0));

			} catch (Exception e) {

				System.out.println("inner try exception handle");
			}

		} finally {

			System.out.println("outer finally9");
		}

		System.out.println("regular code 10");
	}

}
