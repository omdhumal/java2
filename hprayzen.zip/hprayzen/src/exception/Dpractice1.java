package exception;

public class Dpractice1 {
	
	

}
