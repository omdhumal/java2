package exception;

public class Null {
	public static void main(String[] args) {
		int a=20;
		int b=0;
		try {
		int c=a/b;
		}catch(Exception e){
			
			//e.printStackTrace();
		
		System.out.println("Exception handle");
		
		}finally{
			
			System.out.println("Always execute!!");
			
			
		}
		
	}

}
