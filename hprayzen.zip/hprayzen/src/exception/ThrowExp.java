package exception;

public class ThrowExp {
	
	 void divide() {
		 
			int a = 10, b = 0, c;

			c = a / b;
		}

		public static void main(String[] args) {
			ThrowExp te = new ThrowExp();
			try {
				te.divide();
			} catch (Exception e) {

				e.printStackTrace();

			}
		
		
		System.out.println("hellow");
		
		
	}
		
		
	}
	



	

