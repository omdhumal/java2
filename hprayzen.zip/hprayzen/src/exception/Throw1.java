package exception;

public class Throw1 {
   // public static ArithmeticException e = new ArithmeticException ();
	
	static ArithmeticException e;

	
	public static void main(String[] args) {
		
		System.out.println(e);

}
}