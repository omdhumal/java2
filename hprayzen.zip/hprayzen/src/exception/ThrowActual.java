package exception;

import java.util.Scanner;

public class ThrowActual extends RuntimeException {
	
	public static void main(String[] args) {
			
		Scanner s = new Scanner (System.in);
		System.out.println(" Enter your age:");
		int age = s.nextInt();
		System.out.println(age);
		try {

		if(age<18) {
			
			throw new ArithmeticException("you are not eligible for vote");
			
			
		}
		
		else {
			
			System.out.println(" Welcome!Vote Successful.");
		}
		}catch(ArithmeticException e) {
			System.out.println("come after years"+(18-age));

	}

}}
