package exception;

public class FinallyEx {
	public static void main(String[] args) {
		
		try {
			System.out.println(" Enter in try");
			
			String s = null;
			
			
		}catch(ArithmeticException a) {
			
			
			System.out.println("Exception not handle");
		}
		
		
	
	
	finally{
		
		System.out.println("finally always executed");
		
		
	}
	}
}
