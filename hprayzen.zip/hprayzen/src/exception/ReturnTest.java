package exception;

public class ReturnTest {
	
	
	public static int roi() {
		
	try {
		System.out.println(10/0);
		return 555;
		
	}
	catch(Exception e) {
		System.out.println(101/0);
		return 666;
		
	}finally {
		System.out.println(102);
		return 777;
	}
		
		
	}
	public static void main(String[] args) {
		ReturnTest rt = new ReturnTest();
		
		System.out.println(rt.roi());
		
	}

}
