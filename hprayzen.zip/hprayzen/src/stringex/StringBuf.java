package stringex;

public class StringBuf {
public static void main(String[] args) {
	
	StringBuffer sb = new StringBuffer("hello");
	sb.append(" world");
	System.out.println(sb);
	
	StringBuffer sb1 = new StringBuffer(20);
	System.out.println(sb1.capacity());
	
	System.out.println(sb.delete(1, 3));
	
	
	
	
	
	
	
	
}
	
	
	
}
