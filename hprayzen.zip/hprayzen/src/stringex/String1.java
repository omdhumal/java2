package stringex;

public class String1 {
	
	public static void main(String[] args) {
		String str = "hello This is Java class";
		String str1 = " world    ";
		String str2 = "ll";
		String str3 = "HELLO";
		String str4 = "  ";
		
		
		System.out.println(str1.trim());
		System.out.println(str.contains(str2));
		System.out.println(str.compareToIgnoreCase(str3)); 
		System.out.println(str4.isEmpty());// space is consider.
		System.out.println(str4.isBlank()); //space is not considerd 
		System.out.println(str.substring(1 , 24));
		System.out.println(str.substring(6));
		System.out.println(str1.repeat(2));
		System.out.println(str1.toUpperCase());
		
		
		
		String [] strArray = str.split(" ");
		System.out.println(strArray.length);
		
	//	for( String array:strArray) {
			
			
	//		System.out.println(array);
	//	}
		
		for(int i=0;i<strArray.length;i++) {
		System.out.println(strArray[i]);
		
		
		
	}
	
	
	}
}
