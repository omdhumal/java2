package stringex;

public class StringFun {
	public static void main(String[] args) {
		
		String str = "Hello World";
		String str1 = "hi";
		
	String str2 = new String("Hello World");
	String str4 = new String ("hi");
	
	
	
	System.out.println(str);
	
	System.out.println(str.concat(str4));
	
	System.out.println(str.charAt(1));
	
	System.out.println(str1.equals(str2));
	
	System.out.println(str == str2);
	
	System.out.println(str.length());
	
	System.out.println(str.contains(str2));
	
	System.out.println(str.trim());
	
	System.out.println(str1.hashCode());
	
	System.out.println(str.split(str4));
	
	System.out.println(str.replace(str4,str2));
	
	System.out.println(str4.substring(1));
	
	

	}
	
	
	
	
	

}
