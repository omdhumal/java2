package stringbuffer;

public class StringB {
	
	public static void main(String[] args) {
		
	StringBuffer sb = new StringBuffer("Dhumal");
	
	System.out.println(sb.capacity());
	System.out.println(sb.length());
	System.out.println(sb.charAt(3));
	
	sb.setCharAt(2,'a');
	System.out.println(sb);
	
	System.out.println(sb.append(1911));
	
	System.out.println(sb.insert(2,"u"));
	
	System.out.println(sb.delete(6, 7));
	
	System.out.println(sb.reverse());
	
	sb.setLength(3);
	System.out.println(sb);
	
	System.out.println(sb.capacity());
	
	sb.trimToSize();
	
	System.out.println(sb.capacity());
	

}
}