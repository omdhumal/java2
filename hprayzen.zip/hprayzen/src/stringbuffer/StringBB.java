package stringbuffer;

import java.util.Scanner;

public class StringBB {
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		System.out.println("enter first name :");
		System.out.println(sc);
		String name = sc.nextLine();
		System.out.println("first name is " +name);
		
		StringBuilder sb = new StringBuilder("Surname_");
		
		sb.append("firstname_").append("secondName.");
		
		System.out.println(sb);
		
		
		
		
		
		
	}

	
	
	
	
	
}
