package garbagecollection;

public class Test {
	
	@Override
	
	protected void finalize(){
	
		
		System.out.println("Garbsge collected:");
		
	}
	
	public static void main(String[] args) {
		Test t = new Test();
		Test t1 = new Test();
		t1.finalize();
	
		System.gc();
		
		
		
	}

}
