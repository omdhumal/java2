package Searilasation;

public class Customer extends Payment {
	
	private String CustName;
	private int CustomerId;
	private transient  String  Aaddress;
	
	
	
	public Customer(String customerName, int cardname, int cvv, String bankname, String custName, int customerId,
			String aaddress) {
		super(customerName, cardname, cvv, bankname);
		CustName = custName;
		CustomerId = customerId;
		Aaddress = aaddress;
	}
	public String getCustName() {
		return CustName;
	}
	public int getCustomerId() {
		return CustomerId;
	}
	public String getAaddress() {
		return Aaddress;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public void setCustomerId(int customerId) {
		CustomerId = customerId;
	}
	public void setAaddress(String aaddress) {
		Aaddress = aaddress;
	}
	
	
	
	

}
