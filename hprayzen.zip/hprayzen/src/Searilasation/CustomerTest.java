package Searilasation;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class CustomerTest {
	public void readdata() {
		try {
		
		FileInputStream fis = new FileInputStream("C:\\Users\\old19\\OneDrive\\Desktop\\seri.txt");
		
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Customer customer = (Customer)ois.readObject();
		
		
		System.out.println(customer.getBankname());
		System.out.println(customer.getAaddress());
		System.out.println(customer.getCardname());
		System.out.println(customer.getCustomerId());
		System.out.println(customer.getCustName());
		System.out.println(customer.getCvv());

		
		}catch(Exception e ) {
			
			e.printStackTrace();
		}
	}
	
	
	
	
	public static void main(String[] args) {
		
	Customer  ct = new Customer("om",123123,678,"sbi","pune",72872,"manoj");
	
	try {
		
		FileOutputStream fos = new FileOutputStream("C:\\Users\\old19\\OneDrive\\Desktop\\seri.txt");
		
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(ct);
		oos.close();
		
	}catch(Exception e){
		
		e.printStackTrace();
	}
			
	CustomerTest ctt = new CustomerTest();
	ctt.readdata();
	}
	
	
		
		
	

}
