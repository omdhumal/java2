package Searilasation;

import java.io.Serializable;

public class Payment implements Serializable {
	
	
	private String CustomerName;
	private int cardname ;
	private static int cvv;
	private String bankname ;
	
	
	public Payment(String customerName, int cardname, int cvv, String bankname) {
		super();
		CustomerName = customerName;
		this.cardname = cardname;
		this.cvv = cvv;
		this.bankname = bankname;
		
		
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public int getCardname() {
		return cardname;
	}
	public int getCvv() {
		return cvv;
	}
	public String getBankname() {
		return bankname;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public void setCardname(int cardname) {
		this.cardname = cardname;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public void setBankname(String bankname) {
		this.bankname = bankname;
	}
	
	
	
	

}
