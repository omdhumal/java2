package Searilasation;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class StudentTest {
	
	public void writedata() {
		
		Student s1 = new Student ("om",68,895768589,"pune");
		try {
		
		FileOutputStream fos = new FileOutputStream("C:\\Users\\old19\\OneDrive\\Desktop\\seri.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(s1);
		oos.close();

		}catch(Exception e) {
			
			e.printStackTrace();
		}
		
	}
	
	
	public void readdata() {
		try {
		FileInputStream fis = new FileInputStream("C:\\Users\\old19\\OneDrive\\Desktop\\seri.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Student student = (Student)ois.readObject();
		
		
		System.out.println(student.getContact());
		System.out.println(student.getId());
		System.out.println(student.getName());
		System.out.println(student.getAddress());


		}catch(Exception e1) {
			
			e1.printStackTrace();
	
		}
		
	}
	public static void main(String[] args) {
		Student s1 = new Student ("om",68,895768589,"pune");

		
		StudentTest st = new StudentTest();
		st.writedata();
		
		StudentTest st1 = new StudentTest();
		st1.readdata();
		
	}

}
