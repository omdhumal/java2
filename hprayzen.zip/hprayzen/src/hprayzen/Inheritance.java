package hprayzen;

public class Inheritance {

}
