package hprayzen;



public class Bank {
	
	
	
	 
	public static void main(String[] args) {
		
		Client client=new Client();
		
		client.setAcno(67457590);
		client.setName("dhumal");
		client.setBranch("nilanga");
		client.setActype("saving");
		
		{
			
			 
			
			System.out.println(client.toString());
		
		
		
		
	
	}

}}
