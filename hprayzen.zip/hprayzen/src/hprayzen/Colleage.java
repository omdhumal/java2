package hprayzen;

public class Colleage extends Teacher {
	
	private String sub="Physics";{
	
	System.out.println(sub);
	
	}
	
	public static void main(String[] args) {
		 
		Teacher teacher = new Teacher ();
		String proff = teacher.math();
		
		// without string syso
	/*System.out.println(teacher.getDesignation());
		System.out.println(teacher.getCollegeName());
		System.out.println(teacher.getCity());
		
		{
		
		//use only when parent class created
		System.out.println(teacher.math()); 
		}*/
		
		Colleage colleage = new Colleage();
		//System.out.println(colleage.getCity());
		System.out.println(colleage.toString());
	}
	
}
