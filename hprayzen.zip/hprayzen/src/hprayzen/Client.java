package hprayzen;

public class Client {
long Acno;
String Name;
String Branch;
String Actype;
public long getAcno() {
	return Acno;
}
public void setAcno(long acno) {
	Acno = acno;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public String getBranch() {
	return Branch;
}
public void setBranch(String branch) {
	Branch = branch;
}
public String getActype() {
	return Actype;
}
public void setActype(String actype) {
	Actype = actype;
}
@Override
public String toString() {
	return "Client [Acno=" + Acno + ", Name=" + Name + ", Branch=" + Branch + ", Actype=" + Actype + "]";
}
  





}
