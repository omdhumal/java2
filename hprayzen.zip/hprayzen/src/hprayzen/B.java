package hprayzen;

public class B extends A {
	
	void M2()
	{
		System.out.println("welcome in the world of photon");
		B b=new B();
		b.m1();
	}
	

}
