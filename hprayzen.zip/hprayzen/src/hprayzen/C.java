package hprayzen;

public class C extends B {
	public static void main(String[] args) {
		B b= new B();
		b.M2();
	
		System.out.println("from c");
	}

}

