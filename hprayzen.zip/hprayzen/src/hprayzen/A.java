package hprayzen;

public class A {
	void m1()
	{
		System.out.println("hellow hp");
	}

}
