package hprayzen;

public class Sinhagad {
	
	int id = 29;
	String name = "om";
	
	
			public static void main(String[] args) {
				
				Sinhagad sinhagad = new Sinhagad();
				
				System.out.println(sinhagad.id);
				System.out.println(sinhagad.name);
			}

}
