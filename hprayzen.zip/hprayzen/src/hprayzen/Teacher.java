package hprayzen;

public class Teacher {
	private String Designation = "patil";
	private String CollegeName = "SGGS";
	public String City = "pune";
	
	
	
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getCollegeName() {
		return CollegeName;
	}
	public void setCollegeName(String collegeName) {
		CollegeName = collegeName;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	
	String math() {
		
	System.out.println(" Math teacher");	
		return " Math teacher";
		
	}
	@Override
	public String toString() {
		return "Teacher [Designation=" + Designation + ", CollegeName=" + CollegeName + ", City=" + City + "]";
	}
	
	
			

}
