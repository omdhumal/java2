package thiss;

public class SuperTest {
	
	public void m1 () {
	
		
		
	}

	
	public static void main(String[] args) {
		Emp emp = new Emp(35,"om", 9999.99f);
		
		System.out.println(emp.toString());
		
		
	}

}
