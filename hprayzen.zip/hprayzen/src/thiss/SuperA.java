package thiss;

public class SuperA {
	
	
	String Color = "Orange" ;

}
