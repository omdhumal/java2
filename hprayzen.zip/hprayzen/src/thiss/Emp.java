package thiss;

public class Emp extends Person {
	float salery;
	
	 Emp(int id, String Name , float salery){
		
		super(id,Name );
		this.salery= salery;
		
	}

	@Override
	public String toString() {
		return "Emp [salery=" + salery + ", id=" + id + ", Name=" + Name + "]";
	}

	 
	
	

}
