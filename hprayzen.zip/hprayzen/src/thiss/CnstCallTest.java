package thiss;

public class CnstCallTest {
	
	public void m1() {
		
		System.out.println(" From m1");
	}
	public static void main(String[] args) {
		CnstCall cnstcall = new CnstCall( );
		
	
		
		
		
	}
	

}
