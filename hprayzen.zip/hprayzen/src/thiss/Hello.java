package thiss;

public class Hello {
	
	public void m1() {
		
		System.out.println("Hellow from m1");
	}

	public void m2() {
	System.out.println("Hellow from m2");	
		this.m1();
		
		
	}
	
	public static void main(String[] args) {
		Hello hellow = new Hello();
		hellow.m2();
	}
	
}
