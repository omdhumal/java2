package thiss;

public class Student {
	int Rollno;
	String name ;
	float fees;
	
	
	public Student( int Rollno, String name, float fees) {
		
		 this.Rollno =  Rollno;
		 this.name = name;
		 this.fees = fees;
		 
		
	}


	@Override
	public String toString() {
		return "Student [Rollno=" + Rollno + ", name=" + name + ", fees=" + fees + "]";
	}
	
	
	
	
	

}
