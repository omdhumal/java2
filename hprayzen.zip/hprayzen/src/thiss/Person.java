package thiss;

public class Person {
	int id;
	String Name;
	
	Person(int id , String Name){
		this.id = id ;
		this.Name = Name;
		
		
		
	}
	
	
	

}
