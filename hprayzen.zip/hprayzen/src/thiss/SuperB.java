package thiss;

public class SuperB extends SuperA {
	
	String Color = "black";
	
	public void M1() {
		
		System.out.println(super.Color);
		System.out.println(Color);
		
		
	}
	
	public static void main(String[] args) {
		
		
		SuperB superb = new SuperB();
		
		superb.M1();
		//System.out.println(superb.colour);
		
		
	}
	
			

}