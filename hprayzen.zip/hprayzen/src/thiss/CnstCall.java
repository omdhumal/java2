package thiss;

public class CnstCall {
	
	
	public CnstCall() {
		this(4);          
		
		System.out.println("constructor called by this");
	}
		
	 CnstCall(int a) {
		 
		// this();  // if above this is not used then int value provide in object
		 
		 System.out.println(a);
		
		  
	}
		
		
		
	}


