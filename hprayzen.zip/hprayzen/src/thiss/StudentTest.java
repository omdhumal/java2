package thiss;

public class StudentTest {
	public void m1 () {
		
		
	}
	
	public static void main(String[] args) {
		
		Student student = new Student (68,"om",9999.99f);
		
		student.toString();
		
		System.out.println(student.toString());
		
		
		
		
	}

}
