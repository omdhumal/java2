package practice;



public class Customertest  {

	public Customer setdata() {
		Customer ca = new Customer();

		ca.setCity("pune");
		ca.setName("om");
		// cs.setrollno("72");
		ca.setRollno(71);

		return ca;
	}

	public static void main(String[] args) {

		Customertest cust = new Customertest();

		Customer cs = cust.setdata();
		//System.out.println(cs.getCity());
		//System.out.println(cs.getName());
		//System.out.println(cs.getRollno());
		System.out.println(cs.toString());

	}

}
