package practice;

public class TestReadOnly {
	public static void main(String[] args) {
		ReadOnly ro = new ReadOnly ();
		ro.toString();
		
		System.out.println(ro.toString());
		
	}

}
