package practice;

public class Pseudocode {

	public int m1(int a, int b) {

		int temp;

		while (b > 0) {
			temp = a % b;
			a = b;
			b = temp;

		}
		/*
		 * temp = a MOD b
		 *  a = b
		 *   b = temp
		 *   end while
		 *   return a
		 */

		System.out.println(a);
		return a;

	}

	public static void main(String[] args) {

		Pseudocode p = new Pseudocode();
		p.m1(10, 6);
		System.out.println();

	}

}
