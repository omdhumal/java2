package practice;

public class Pseudocode1 {
	public void m1(int a, int b, int c, int d) {
		a=b-c;
		for(c=a-1;c<=1;c++) {
			
			b= b+c+12;
			b=b/5;
			d=b+a;
			
		}
	     c=a+b+c;

		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		

		
		
	}
	public static void main(String[] args) {
		Pseudocode1 p1 = new Pseudocode1();
				p1.m1(1, 18, 12,1);
				
		
	}

	
	
}
/*integer a, b, c, d
Set b = 18, c = 12
a = b � c
for (each c from 1 to a � 1)
            b = b + c + 12
            b = b/5
            d = b + a
end for
c = a + b + c
Print a b c*/