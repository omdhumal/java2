package practice;

public class MahaEx {
	String Bankname;
	int acno;
	String custName;

	public String getBankname() {
		return Bankname;
	}

	public void setBankname(String bankname) {
		Bankname = bankname;
	}

	public int getAcno() {
		return acno;
	}

	public void setAcno(int acno) {
		this.acno = acno;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	//@Override
	public String toString() {
		return "MahaEx [Bankname=" + Bankname + ", acno=" + acno + ", custName=" + custName + "]";
	}

	public static void main(String[] args) {

		MahaEx mahaex = new MahaEx();

		mahaex.setAcno(34645);
		mahaex.setBankname("Sbi");
		mahaex.setCustName("om");

		System.out.println(mahaex.toString());

	}

}
