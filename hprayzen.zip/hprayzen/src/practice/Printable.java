package practice;

public interface Printable {
	
	void print();

}
