package practice;

class Customer{


	private String name;
	private int rollno;
	private String city;



	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	//@Override
	public String toString() {
		return "Customer [name=" + name + ", rollno=" + rollno + ", city=" + city + "]";
	}

	
	

	
	}

	
	

    


