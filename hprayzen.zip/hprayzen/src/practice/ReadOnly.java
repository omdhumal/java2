package practice;

public class ReadOnly {
	private String name = "om";
	private int rollno = 20;
	private long mono = 915801026;
	private float pointer = 8.26f;
	
	// For read only use getter only 
	
	public String getName() {
		return name;
	}
	public int getRollno() {
		return rollno;
	}
	public long getMono() {
		return mono;
	}
	public float getPointer() {
		return pointer;
	}
	//for write only use setter method.
	
	
	/*public void setName(String name) {
		this.name = name;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public void setMono(int mono) {
		this.mono = mono;
	}
	public void setPointer(float pointer) {
		this.pointer = pointer;
	}*/
	//@Override
	public String toString() {
		return "ReadOnly [name=" + name + ", rollno=" + rollno + ", mono=" + mono + ", pointer=" + pointer + "]";
	}
	
	
	

}
