package practice;

abstract class AbstractEx {

	abstract void name();

	void rollno() {

	}

}
