package practice;

public class Capgimini {
	public int m1(int a, int b) {
		if(a<3||b<3|| a+b>8) {
			  
			return (a+1)+ m1(b+1,a+1)+(b+1);
			//System.out.println(a);
		}
		System.out.println(a);

		return a;
		
		
	}public static void main(String[] args) {
		Capgimini c =new Capgimini();
		c.m1(2, 2);
		//System.out.println(a);
	}
}
