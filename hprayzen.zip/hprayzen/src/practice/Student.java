package practice;

public class Student {
 int customerId;
 String customerName;
   // private Address address;
	
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	//}
//	public Address getAddress() {
//		return address;
	//}
//	public void setAddress(Address address) {
	//	this.address = address;
	//}
	
	
	

}


}
