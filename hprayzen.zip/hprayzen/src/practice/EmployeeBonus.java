package practice;

public class EmployeeBonus extends Employee {
	
	int bonous= 5000;
	
	
	
	public static void main(String[] args) {
		EmployeeBonus eb = new EmployeeBonus();
		
	float	totalsallery = eb.salery + eb.bonous ;
		
		System.out.println("total salery is :" +totalsallery);
		
		
		
		
	}

}
