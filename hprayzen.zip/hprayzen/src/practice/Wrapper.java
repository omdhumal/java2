package practice;

public class Wrapper {
	
	static int a = 27;
	  
	public static void main(String[] args) {
	//	Wrapper w = new Wrapper();
		Integer i = a;
		
		System.out.println(i);
	}
}
