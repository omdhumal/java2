package practice;

public class StudentID {

  private String StudentNAme;
  private String SttudentRoll;
  private int Pincode;
  
	
}
