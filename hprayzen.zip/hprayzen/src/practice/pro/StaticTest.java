package practice.pro;

public class StaticTest {
	//static String name="om";
	static int count= 0;  // static variable stores latest value 
	       int i=0;
	
	void m1() {
		//name="dhumal";
		//count = 4;
		count++;
		i++;
		System.out.println(count+" "+i);
		
	}
	
	static void m2() {
		count =10;
		count++;
		System.out.println(count);
	}
	

	public static void main(String[] args) {
		StaticTest s1= new StaticTest();
		StaticTest s2 = new StaticTest();
		StaticTest s3 = new StaticTest();
		s1.m1();
		s2.m1();
		s3.m1();
		
		s1.m2();
		s2.m2();
		s3.m2();
		

	}

}
