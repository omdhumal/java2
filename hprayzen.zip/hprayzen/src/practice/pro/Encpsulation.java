package practice.pro;

public class Encpsulation {
	private int ac_no;
	private int mo_no;
	private String name;
	private float balance;
	
	
	
	public int getAcno() {
		return ac_no;
		
	}
	
	public void setAcno(int acno) {
		
		this.ac_no=acno;
		
	}

	public int getMo_no() {
		return mo_no;
	}

	public String getName() {
		return name;
	}

	public float getBalance() {
		return balance;
	}

	public void setMo_no(int mo_no) {
		this.mo_no = mo_no;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Encpsulation [ac_no=" + ac_no + ", mo_no=" + mo_no + ", name=" + name + ", balance=" + balance + "]";
	}
	


}
