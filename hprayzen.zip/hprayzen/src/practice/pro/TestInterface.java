package practice.pro;

public class TestInterface implements Skillable{
	
	public static void main(String[] args) {
		TestInterface ti = new TestInterface();
		ti.sketch();
		ti.shape();
		ti.image();
		ti.line();
		ti.test();
		
		
	}

	public void sketch() {
	
		System.out.println("Sketching");
	}

	@Override
	public void image() {
		System.out.println("drawing");
		
	}

	@Override
	public void line() {
		System.out.println("lining");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void shape() {
		// TODO Auto-generated method stub
		System.out.println("shaping");
	}

	@Override
	public void test() {
		// TODO Auto-generated method stub
	System.out.println("test qualified");	
	}

}
