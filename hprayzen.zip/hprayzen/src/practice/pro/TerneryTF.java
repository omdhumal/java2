package practice.pro;

public class TerneryTF {
	
	public static void main(String[] args) {
		
		int num= 12;
		
		String even = (num%2==0)? "Number is even":"Number is odd";
		System.out.println(even);
	}

}
