package practice.pro;

public class Polymorphism {
	
	public int getfees (int fees) {
		
		return fees;
	}	

}

class Coep extends Polymorphism{
	
public int getfees (int fees) {
		
		return 90000;
}
}

class Sggs extends Polymorphism{
	
public int getfees (int fees) {
		
		return 86000;
}
}
class Iit extends Polymorphism{
	
public int getfees (int fees) {
		
		return 100000;
}
}
