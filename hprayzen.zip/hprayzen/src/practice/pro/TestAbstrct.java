package practice.pro;

public class TestAbstrct extends Student {
	
	public static void main(String[] args) {
		
		Abstraction a= new Student();
		
		a.id();
		a.password();
		a.acstatus();
		a.details();
	}

}
