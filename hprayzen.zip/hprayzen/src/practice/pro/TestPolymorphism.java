package practice.pro;

public class TestPolymorphism {
	
	public static void main(String[] args) {
		
		Polymorphism p;
		
		    p= new Sggs();
		    
		   System.out.println(p.getfees(0));
		
	}

}
