package practice.pro;

public class ObjectInitialize {
	
	public static void main(String[] args) {
		 Student1 s= new Student1();
		 s.name="om";
		 s.id=11;
		 
		// s.name="omd";
		 //s.id=111;
		 
		 s.m1();
		 
		 student2 s2 = new student2();
		 s2.m2("RUTU", 21);
		 s2.m2("ved", 31);
		
	}
}
	
	 class Student1{ 
		 
		 String name;
		 int id;
		
		public void m1() {
			System.out.println(name+" "+id);
		}}
		
	 
	 class student2{
		 
		 String name;
		 int id;
		 
		 public String m2(String name,int id) {
			
			System.out.println(name+" "+id);
			return name;
 
		 }
		 
		 
		 
	 
	 }


