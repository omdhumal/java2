package practice.pro;

public class Child1 implements Parent1 {
	void c1() {
		System.out.println("c1 called from child");
	}
	@Override
	public void m1() {
		System.out.println("m1 called from ");
		
	}
	public static void main(String[] args) {
		
		Child1 p = new Child1();
		p.m1();
		p.c1();
		
	}
	
}
