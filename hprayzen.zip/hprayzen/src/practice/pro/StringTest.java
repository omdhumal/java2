package practice.pro;

public class StringTest {
	
	public static void main(String[] args) {
		
		
		char ch[] = {'f','a','a','n','g'};
		
		String aim = new String (ch);
		System.out.println("aim is: "+aim);
		
		String s1= "Dhumal";
		    
		String s2="Dhumal";
		String s3 = new String("Dhumal");
		String s4= " Om  ";
		String s5= "DHUMAL";
		
		s5=s5.concat(" Don");
		System.out.println(s5);
		
		String t1= s1.concat(s4);
		System.out.println(t1);
		
		s1.compareTo(s2);
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s4));
		System.out.println(s1.compareTo(s3));
		System.out.println(s4.compareTo(s3));

		System.out.println(s1.substring(3, 6));
		
		System.out.println(s1.equals(s2));
		System.out.println(s1.equals(s3));

		System.out.println(s2==s1);
		System.out.println(s1==s3);
		
		System.out.println(s1.equalsIgnoreCase(s5));
		System.out.println(s5.toLowerCase()==s1);
		
		s5.toLowerCase().equals(s1);
		System.out.println(s5.toLowerCase().equals(s1));
		
		
		System.out.println(s4.trim());
		System.out.println(s5.length());
		System.out.println(s1.charAt(0));
		
		}

}
