package practice.pro;

public interface Drawable {
	
	void sketch();
	
	void image();

}
