package practice.pro;

public interface Skillable extends Drawable,Prinatable {
	static int id=21;
	final String level="Expert";
	
	void test();
		
		
		
		
	}


