package practice.pro;

public class Overriding {
	
	public void edu(int year, String branch) {
		
		System.out.println(" I am from "+year+"year "+branch+" Department");
		
	}
	
	

}
