package practice.pro;

 class Parent {
	
	void m1() {
		System.out.println("m1 called from superclass");	
	}
	
	void m2() {
		System.out.println("m2 called from superclass");
	}

}

 
