package practice.pro;

public class StringBuff {
	public static void main(String[] args) {
	
	StringBuffer sb = new StringBuffer("Rolex");
	

	
	System.out.println(sb.insert(1, "ohh"));
	System.out.println(sb.replace(1,8,"adow")); 
	
	System.out.println(sb.delete(0, 3));
	
	}
}
