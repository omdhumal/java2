package practice.pro;


	class Child extends Parent {
		 
		 void n1() {
			 System.out.println("n1 called from subclass");
			 
		 }
		 
		 void n2() {
			 System.out.println("n2 called from subclass");
		 }
		 
		 public static void main(String[] args) {
			
			// Subclass s = new SuperClass();   //child reference can't hold parent object.
			 
			 Parent s1= new Child();//only parent methods called
			 s1.m1();
			 s1.m2();
			 
			 
		}
		
	}


