package practice.pro;

public class TestEncpsulation {
	
	public static void main(String[] args) {
		Encpsulation e = new Encpsulation();
		e.setAcno(60326308);
		System.out.println(	e.getAcno());
		e.setBalance(5000000.00f);
		e.setMo_no(915801026);
		e.setName("om");
		
		e.toString();
		System.out.println(e.toString());
	}

}
