package practice.pro;

public interface Prinatable {
	
	void line();
	
	void shape();

}


