package practice.pro;

public class StringBuild {

	public static void main(String[] args) {
		
		StringBuilder sb= new StringBuilder("Dhumal");
		
		StringBuilder sb2= new StringBuilder("Dhumal");

		System.out.println(sb.equals(sb2));
		System.out.println(sb==sb2);

	}

}
