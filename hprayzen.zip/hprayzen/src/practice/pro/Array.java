package practice.pro;

public class Array {

	public static void initialization() {

		int[][] Array2 = { { 10, 20, 30, 40 }, { 50, 60, 70, 80 } };

		int b1[] = { 10, 20, 30 };
		// System.out.println(a[0][0]);

		Array ar = new Array();

		ar.getArray(b1);

	}

	public void getArray(int a[]) {

		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
			// System.out.println(a[i]);

		}
	}

	public static void main(String[] args) {
		Array ar = new Array();
		ar.initialization();

		//ar.getArray();

	}
}
