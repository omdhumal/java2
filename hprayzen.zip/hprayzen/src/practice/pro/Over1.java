package practice.pro;

public class Over1 extends Overriding{
	
	public void edu(int year, String branch) {
		System.out.println(" from over 1");
	}

	
	public static void main(String[] args) {
		Over1 o1= new Over1();
	//	o1.edu(1, "civil");
		
		
		Overriding over = new Overriding();
		
		over.edu(2, "cse");
	}
}
