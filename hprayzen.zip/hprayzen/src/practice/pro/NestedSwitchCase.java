package practice.pro;

public class NestedSwitchCase {
	
	
	public static void main(String[] args) {
		String branch= "Civil";
		
		int year= 2;
		switch(year) {
		case 1:
			switch(branch) {
			case "Civil":
			
			    System.out.println("FY Civil Engineering");
			
			break;
			
		    case "Cse" :
		    	System.out.println("FY computer Science Engineering");
		
		    break;
		    
		    default:System.out.println("You Are Not From Civil or Cse");
		    	
		    	
			}
			break;
			
		case 2:
			switch(branch) {
			case "Civil":
			
			System.out.println("SY civil Engineering");
			break;
			case "Cse":
				System.out.println("SY CSE");
			break;
			default:System.out.println("You are not from SY civil/cse");
			}	
		}
	}

}
