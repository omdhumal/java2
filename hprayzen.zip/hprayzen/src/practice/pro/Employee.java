package practice.pro;


	
	public class Employee{
		
	 String name;
	 int id;
	   float salery;
	    
	   public Employee(String n, int i, float s){
	    	 name=n;
		     id=i;
		    salery=s;
	    }
	    
	    public Employee(String s, int i) {
			// TODO Auto-generated constructor stub
	    	name=s;
	    	id=i;
		}

		void m1() {
	    	System.out.println(name+" "+id+" "+salery);
	    }
		public static void main(String[] args) {
			
			Employee e1= new Employee("om", 22, 50000) ;
			Employee e2= new Employee("om", 22) ;

			e1.m1();
			e2.m1();
	    
	}

}
