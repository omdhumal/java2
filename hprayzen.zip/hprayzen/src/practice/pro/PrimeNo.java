package practice.pro;

import java.util.Scanner;

public class PrimeNo {

	public static void main(String[] args) {

		int a, b, i, j, n, m;

		Scanner sc = new Scanner(System.in);
		System.out.println("inter first number:");
		a = sc.nextInt();

		Scanner s = new Scanner(System.in);
		System.out.println("inter end number:");
		b = s.nextInt();

		for (i = a; i <= b; i++) {
			// n=i;
			m = 0;

			for (j = 2; j <= i - 1; j++) {

				if (i % j == 0) {
					m = 1;
					System.out.println("number is not prime" + i);
					break;
				}
			}
			if (m == 0) {

				System.out.println("number is prime" + i);
			}

		}

	}
}
