package practice.pro;

public interface Parent1 {
	void m1();
}
