package practice.pro;

public class FrenchComp {
	
	public void b1() {
		
		System.out.println("B1 is called from france");
	}
	
	public int b2(int b, int g) {
		
		int total = b+g ;
		System.out.println(total);
		
		return total;
		
	}
	
	public int b2(int b, int g, int l) {
		int total = b+g+l;
		System.out.println(total);
		return total;
		
	}
	
	public static void main(String[] args) {
		FrenchComp f1 = new FrenchComp();
		f1.b1();
		
		India in= new India();
		in.pune();
	


		Usa u = new Usa();
		u.california();
	}

}

class India{
	
	public void pune(){
		FrenchComp fc = new FrenchComp();
		System.out.print("India:");
		fc.b2(12,23);
		}
	}

class Usa {
	
	public void california() {
		FrenchComp fc = new FrenchComp();
		System.out.print("california:");

		fc.b2(12,23,25);
		
		
		
	}
	 
	 
 }


