package practice.pro;

abstract class Abstraction {
	
	public void details() {
		
		System.out.println("Details Available");
	}
	
	
	void password() {}
	
	
	
	final void id() {
		System.out.println("Id Generated");
	}
	
	public static void acstatus() {
		System.out.println("Ac verified");
		
	}
	
	

}

class Student extends Abstraction{
	
	void password() {
		System.out.println("password is generated");
	}
	
}
