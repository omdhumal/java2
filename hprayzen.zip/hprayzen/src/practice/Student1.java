package practice;

import java.util.Scanner;

public class Student1 extends AbstractEx {

	void name() {

		System.out.println("om dhumal");
	}

	void rollno() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter your roll number:");
		int rollNo = sc.nextInt();
		if (rollNo <= 20) {

			System.out.println("You are in group A :" + rollNo);
		} else {
			System.out.println("your from B Group:" + rollNo);
		}

	}

	public static void main(String[] args) {

		AbstractEx ae = new Student1();
		ae.name();
		ae.rollno();

	}

}
