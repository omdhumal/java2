package practice;

public class InterfaceTest implements Printable , Showable {
	
	public void show() {
		
		System.out.println("show method implimented");
		
	}
	
	public void print() {
		
		
		System.out.println("print method implimented");
		
	}

	public static void main(String[] args) {
		InterfaceTest p = new InterfaceTest();
		//Showable s = new InterfaceTest ();
		
		p.show();
		p.print();
	}
}


