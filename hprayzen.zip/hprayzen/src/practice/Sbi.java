package practice;

public class Sbi extends Override {
	
	public int Bank() {
		
	//	int ROI ;
		
	return 5;	
		
	}
	
	
	public static void main(String[] args) {
		Sbi sbi  = new Sbi();
		
		System.out.println(sbi.Bank());
		
		
		
		
		
	}
	

}
