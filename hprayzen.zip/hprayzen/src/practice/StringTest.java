package practice;

import java.util.Scanner;

public class StringTest {
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter city name:");

		String name = sc.nextLine().trim().toLowerCase();
		
		{
		if (name.equalsIgnoreCase("mumbai")) {

			System.out.println("Dream is here");
		}

		else if (name.equals("pune")) {
			System.out.println("Shanivarwada is here");

		}
		
		else if (name.equals("latur")){
			
			System.out.println("Welcome in latur");
			
		}
		
		else if (name.equals("nanded")) {
			
			
			System.out.println("Gurudwar is here");
		}
	
		else System.out.println("Enter Valid city");
		
		
		
	}}

	
	
}
