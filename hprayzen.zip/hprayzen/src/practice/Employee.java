package practice;

public class Employee {
	
	float salery = 40000;
	
	

}
