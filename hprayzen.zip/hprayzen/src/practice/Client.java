package practice;

public class Client {
	private String cname;
	private String ccity;
	private int num;
	
	
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getCcity() {
		return ccity;
	}
	public void setCcity(String ccity) {
		this.ccity = ccity;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	
	}
	//@Override
	public String toString() {
		return "Client [cname=" + cname + ", ccity=" + ccity + ", num=" + num + "]";
	}
	
	
	
	
	

}
