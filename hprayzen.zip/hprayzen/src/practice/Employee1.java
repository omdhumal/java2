package practice;

public class Employee1 {
	
	String name ;
	String Shift;
	int rno;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getShift() {
		return Shift;
	}
	public void setShift(String shift) {
		Shift = shift;
	}
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	//@Override
	public String toString() {
		return "Employee1 [name=" + name + ", Shift=" + Shift + ", rno=" + rno + "]";
	}
	

}
