package practice;

public interface Showable {
	
	void show();
	

}
