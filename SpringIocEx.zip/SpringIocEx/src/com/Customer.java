package com;

public class Customer {
	public int customerId;
	public String CustomerName;
	
	
	public Customer(int customerId, String customerName) {
		super();
		this.customerId = customerId;
		CustomerName = customerName;
	}
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}

	public void printData() {
		System.out.println("id:"+customerId);
		System.out.println("name:"+CustomerName);

		
	}
	
	

}
