package com;

public class Employee {
	
	public void getEmp() {
		System.out.println("Employee called..");
	}

}
