package tech;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Image {
	public static void main(String[] args) {
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");	
		PreparedStatement pstmt = conn.prepareStatement( "insert into user values(?,?,?,?,?,?,?,?) ");
		
		pstmt.setInt(1, 1501);
		pstmt.setString(2, "om");
		pstmt.setString(3, "om1");
		pstmt.setString(4, "punr");
		pstmt.setString(5, "om");
		pstmt.setString(6, "om24242");
		pstmt.setString(8, "photo");
	FileInputStream fis = new FileInputStream("C:\\Users\\old19\\Downloads");
	
		
		pstmt.setBinaryStream(7, fis,fis.available());

		
		
	} catch (Exception e) {
		
		e.printStackTrace();
	}
	
}


}
