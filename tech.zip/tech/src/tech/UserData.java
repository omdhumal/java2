package tech;

import java.util.ArrayList;
import java.util.List;

public class UserData {
	public List<User> filtreUserData(String useraddress) {
		
		List<User> filtrelist = new ArrayList<>();
		JdbcConnection jdbcc= new JdbcConnection();
		List<User> list2 = jdbcc.getAllUsearData();
		for(User user : list2) {

			if(user.getUseraddress().equalsIgnoreCase(useraddress)) {
			
				System.out.println(user);
				
			}
			
			
		}
		return filtrelist;
		

		
		
	}
	public static void main(String[] args) {
		
		UserData ud = new UserData();
		ud.filtreUserData("mumbai");
		
		JdbcConnection jdbcc= new JdbcConnection();
		List<User> list2 = jdbcc.getAllUsearData();
		//System.out.println(list2.toString());
		for(User user:list2) {
			
			
			if(user.getUsername().equalsIgnoreCase("om")) {
			//	System.out.println(user);	
			}
			
			//System.out.println(user);
		}
		
		

	}



}
