package tech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class JdbcConnection {
	
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Step 1");
			Connection conn = 
					DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");
			System.out.println("Step 2");
			Statement stmt = conn.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from user ");
			System.out.println("step 4");
			
			while(rs.next()) {
				System.out.println(rs.getString("user_address"));
				System.out.println(rs.getString("user_pass"));
				System.out.println(rs.getString("gender"));
				System.out.println(rs.getString("mobile_no"));
				System.out.println(rs.getString("id"));
			}
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	public List<User> getAllUsearData() {

		List<User> list2 = new ArrayList<>();

		try {
		
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Step 1");
		Connection conn = 
				DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");	
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select * from user ");    //...where id = 2 direct filtre
		
		while(rs.next()) {
			User user = new User();    


		user.setUsername(rs.getString("user_name"));
		user.setId(rs.getInt("id"));
		user.setUsearpass(rs.getString("user_pass"));
		user.setUseraddress(rs.getString("user_address"));
		user.setGender(rs.getNString("gender"));
		user.setMobileno(rs.getString("mobile_no"));

		list2.add(user);
		
		}
		
		}catch(Exception e) {
			
			e.printStackTrace();
		}
		return list2;
		
		

	}
	
	

}
