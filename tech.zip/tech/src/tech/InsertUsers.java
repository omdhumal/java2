package tech;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;





public class InsertUsers {
	
	public void UsersData() {
		List<User> list = new ArrayList();
		
		User user1 = new User (12,"yash","dhu2","latur","m","m121212");
		User user2 = new User (13,"shri","dhu3","france","m","m121212");
		User user3 = new User (14,"ram","dhu4","usa","m","m121212");
		User user4 = new User (15,"jay","dhu5","uk","m","m121212");
		
		list.add(user1);
		list.add(user2);
		list.add(user3);
		list.add(user4);

		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = 
					DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");	
			Statement stmt = conn.createStatement();
			System.out.println("saved1");
			for(User useru:list) {
			int i = stmt.executeUpdate("insert into user values ("+useru.getId()+",'"+useru.getUsername()+"','"+useru.getUsearpass()+"','"+useru.getUseraddress()+"','"+useru.getGender()+"','"+useru.getMobileno()+"')");
			System.out.println("loop");
			}
			
			
			
		} catch (Exception e) {
			e.getMessage();
			//e.printStackTrace();
		}
	
	}
	
	public void preparedstmt() {
		InsertUsers idu = new InsertUsers();
		List<User> lista=idu.preparedata();
		//User user = new User();
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = 
					DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");	
			PreparedStatement pstmt = conn.prepareStatement("insert into user values (?,?,?,?,?,?,?,?)");
			//System.out.println("saved1");
			for(User useru:lista) {
				
				pstmt.setInt(1,useru.getId());
				pstmt.setString(2, useru.getUsername());
				pstmt.setString(3, useru.getUsearpass());
				pstmt.setString(4, useru.getUseraddress());
				pstmt.setString(5, useru.getGender());
				pstmt.setString(6, useru.getMobileno());
				pstmt.setString(7, "myimage");
				
				FileInputStream fis = new FileInputStream("C:\\Users\\old19\\Downloads\\photo.jpg");
				
				pstmt.setBinaryStream(8, fis,fis.available());
				
				int i=pstmt.executeUpdate();
				System.out.println(i);
				System.out.println("saved1");
			}
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
	}	
		
	public List<User> preparedata() {
		List<User> lista = new ArrayList();
		User user11 = new User (332,"yash dhumal","dhu22","latur","m","m1212129");
		User user12 = new User (333,"shri dhumal","dhu223","france","m","m1212128");
		User user13 = new User (334,"ram patil","dhu24","usa","m","m1212127");
		User user14 = new User (335,"jay whagh","dhu25","uk","m","m1212126");
		
		lista.add(user11);
		lista.add(user12);
		lista.add(user13);
		lista.add(user14);
		
		return lista;
	}
	
	public void retriveImage() {
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = 
				DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");	
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select * from user where id= 332");
		while(rs.next()) {
			User user = new User();
			user.setId(rs.getInt(1));
			user.setUsername(rs.getString(2));
			user.setUsearpass(rs.getString(3));
			user.setUseraddress(rs.getString(4));
			user.setGender(rs.getString(5));
			user.setMobileno(rs.getString(6));
			user.setPhoto(rs.getString(7));
			//user.setImage(rs.getBlob(8));
			
			
			Blob bl = rs.getBlob(8);
			byte [] brr = bl.getBytes(1, (int)bl.length());
			FileOutputStream fos = new FileOutputStream("C:\\Users\\old19\\OneDrive\\Desktop\\abc.bmp");
			fos.write(brr);
			//user.setImage(bl);
			
			fos.close();
			
			if(user.getUsername().equalsIgnoreCase("yash dhumal")) {
				
				System.out.println(user.toString());
			}
		
		}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}


	public static void main(String[] args) {
		InsertUsers iu = new InsertUsers();
		//iu.UsersData();
		//iu.preparedstmt();
		iu.retriveImage();
	}

}
