package tech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertData {
	public User setData() {
		InsertData in = new InsertData();
		User user = new User ();
		user.setId(100);
		user.setUsername("photon");
		user.setUsearpass("d1");
		user.setUseraddress("LATUR");
		user.setGender("m");
		user.setMobileno("m22552552");
		
		//String msg = in.setData(user);
		
		
		return user;
		
		
		
	}
	
/*	public User deleteuserdata(int id) {
		User user1 = new User();
		InsertData in = new InsertData();
       user1= in.setData();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = 
					DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");	
			Statement stmt = conn.createStatement();
			System.out.println("saved1");
			int i = stmt.executeUpdate("delete from  user where id = "+user1.getId()+"");
			System.out.println("saved2");
			if(i>0) {
				
				System.out.println("deleted data succesful");
				
				
			}else {
				
				System.out.println("data not deleted");
			}
		} catch (Exception e) {
			e.getMessage();
		}
		
		return user1;
		
		
	}*/
	
	public User UpdateUserData() {
		InsertData id1 = new InsertData();
		
		User user1 = new User();
		user1= id1.setData();
		user1.setUseraddress("usa");
		user1.setMobileno("m1111");
		user1.setId(1);
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = 
					DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");	
			Statement stmt = conn.createStatement();
			System.out.println("saved1");
			int i = stmt.executeUpdate("update  user set  user_address = '"+user1.getUseraddress()+"',mobile_no = '"+user1.getMobileno()+"' where id="+user1.getId()+"");
			System.out.println("saved2");
			if(i>0) {
				
				System.out.println("deleted data succesful");
				
				
			}else {
				
				System.out.println("data not deleted");
			}
		} catch (Exception e) {
			e.getMessage();
		}
		
		
		return user1;
		
		
	}
	
	
	
	
	public static void main(String[] args) {
		User user1 = new User();
		
		InsertData in = new InsertData();
		//user1 =in.setData();
		
		//in.deleteuserdata(100);
		in.UpdateUserData();
		
		/*try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = 
					DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");	
			Statement stmt = conn.createStatement();
			System.out.println("saved1");
			int i = stmt.executeUpdate("insert into user values ("+user1.getId()+",'"+user1.getUsername()+"','"+user1.getUsearpass()+"','"+user1.getUseraddress()+"','"+user1.getGender()+"','"+user1.getMobileno()+"')");
			System.out.println("saved2");
			if(i>0) {
				
				System.out.println("inserted data succesful");
				
				
			}else {
				
				System.out.println("data not saved");
			}
		} catch (Exception e) {
			e.getMessage();
			//e.printStackTrace();
		}*/
		
		

		
	}

}
