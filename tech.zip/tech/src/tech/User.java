package tech;
import java.sql.*;
//import com.mysql.cj.jdbc.Blob;

public class User {
	
	private int id;
	private String username;
	private String usearpass;
	private String useraddress;
	private String gender;
	private String mobileno; //int 
	private Blob image;
	private String photo;
	
	
	public User() {
		super();
	}
	
	
	public User(int id, String username, String usearpass, String useraddress, String gender, String mobileno) {
		super();
		this.id = id;
		this.username = username;
		this.usearpass = usearpass;
		this.useraddress = useraddress;
		this.gender = gender;
		this.mobileno = mobileno;
	}


	public User(int id, String username, String usearpass, String useraddress, String gender, String mobileno,Blob image,String photo) {
		super();
		this.id = id;
		this.username = username;
		this.usearpass = usearpass;
		this.useraddress = useraddress;
		this.gender = gender;
		this.mobileno = mobileno;
		this.image= image;
		this.photo= photo;
		
		
		
		
	}
	
	
	public String getPhoto() {
		return photo;
	}


	public void setPhoto(String photo) {
		this.photo = photo;
	}


	public Blob getImage() {
		return image;
	}


	public void setImage(Blob image) {
		this.image = image;
	}


	public String getUsearpass() {
		return usearpass;
	}
	public void setUsearpass(String usearpass) {
		this.usearpass = usearpass;
	}
	public int getId() {
		return id;
	}
	public String getUsername() {
		return username;
	}
	public String getUseraddress() {
		return useraddress;
	}
	public String getGender() {
		return gender;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setUseraddress(String useraddress) {
		this.useraddress = useraddress;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", usearpass=" + usearpass + ", useraddress=" + useraddress
				+ ", gender=" + gender + ", mobileno=" + mobileno + ", image=" + image + ", photo=" + photo + "]";
	}
	
	
	

}
