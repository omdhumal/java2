package tech;

public class Sbi {
	private int acno;
	private String name;
	private String ifsc;
	private String branch;
	private int id;
	
	
	
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getAcno() {
		return acno;
	}
	public String getName() {
		return name;
	}
	public String getIfsc() {
		return ifsc;
	}
	public int getId() {
		return id;
	}
	public void setAcno(int acno) {
		this.acno = acno;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Sbi [acno=" + acno + ", name=" + name + ", ifsc=" + ifsc + ", branch=" + branch + ", id=" + id + "]";
	}
	
	

}
