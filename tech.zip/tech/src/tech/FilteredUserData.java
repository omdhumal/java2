package tech;

import java.util.List;

public class FilteredUserData {
	public static void main(String[] args) {
		UserData ud = new UserData();
		List<User> filteredlist=ud.filtreUserData("mumbai");
		System.out.println(filteredlist);
		
		
		
	}

}
