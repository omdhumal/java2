package tech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Jdbcconnection2 {

	public static List<Sbi> getalldata() {
		List<Sbi> list = new ArrayList<>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step1");

			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "Dhumal@123");
			System.out.println("step2");
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from sbi ");
			while (rs.next()) {
				//Sbi sbi = new Sbi();

				 System.out.println(rs.getString("acc_no"));
				// System.out.println(rs.getString("name"));
				// System.out.println(rs.getString("id"));
				// System.out.println(rs.getString("ifsc"));

			//	sbi.setAcno(rs.getInt("acc_no"));
			//	sbi.setName(rs.getString("name"));
			//	sbi.setId(rs.getInt("id"));
			//	sbi.setIfsc(rs.getString("ifsc"));

			//	list.add(sbi);
			//	for (Sbi sbi1 : list) {
					// System.out.println(sbi1);

				}
		//	}

		} catch (Exception e) {

			// e.printStackTrace();
		}
		return list;

	}

	public static void main(String[] args) {
		Jdbcconnection2 jd = new Jdbcconnection2();
		List<Sbi> list1 = jd.getalldata();
		Sbi sbi = new Sbi();
		for (Sbi sbi1 : list1) {
			System.out.println(sbi1);
		}

	}
}
