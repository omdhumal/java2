package tech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SbiData {
	public static  List<Sbi> getData() {
		List<Sbi> list = new ArrayList<>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step1");

			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "Dhumal@123");
			System.out.println("step2");
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("select * from sbi ");
			while (rs.next()) {
			

				 System.out.println(rs.getString("acc_no"));
				 System.out.println(rs.getString("name"));
}	
		} catch (Exception e) {
		
			
		}
		return list;
		
	}
	public static void main(String[] args) {
		SbiData sd = new SbiData();
		List<Sbi> list1=sd.getData();
		Sbi sbi= new Sbi();

		for(Sbi sbi1:list1 ) {
			
			System.out.println(sbi1);
			
		}
	}

}
