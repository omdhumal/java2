package tech;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class InsertImage {
	
	public static void main(String[] args) {
	
			try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b15","root","Dhumal@123");	
			PreparedStatement pstmt = conn.prepareStatement( "insert into user values(?,?,?,?,?,?,?,?) ");
			
			pstmt.setInt(1, 100);
			pstmt.setString(2, "om");
			pstmt.setString(3, "om1");
			pstmt.setString(4, "punr");
			pstmt.setString(5, "om");
			pstmt.setString(6, "om24242");
			pstmt.setString(7, "photo");
		FileInputStream fis = new FileInputStream("C:\\Users\\old19\\Downloads");
		
			
			pstmt.setBinaryStream(8, fis,fis.available());

			
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

	
		
	
		
	}


